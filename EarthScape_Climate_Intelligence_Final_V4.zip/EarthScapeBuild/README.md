# EarthScape Climate Intelligence — Final Build

A Flask + MongoDB climate and weather analysis application with a trainable multi-variable AI forecasting system.

## Stack

- Python + Flask
- MongoDB
- Server-rendered HTML
- CSS + vanilla JavaScript
- Pandas / NumPy / scikit-learn / Joblib

## What is implemented

### Functional project requirements

- Secure authentication and role-based authorization
- Weather-station, environmental-sensor and satellite data ingestion
- Historical and real-time observations
- CSV, XLSX, JSON and GeoJSON climate tables
- Satellite image asset ingestion and preview/download
- Organized MongoDB storage with timestamp, region, source and monthly partition indexes
- Validation and configurable missing-data repair
- Parallel partitioned batch analytics
- Climate patterns, anomalies and correlations
- Real-time processing integrated with the batch climate store
- Multi-variable machine-learning forecasting
- Temperature, humidity, pressure, wind, rainfall and cloud-cover forecasting for 10 days
- Human-readable weather interpretation such as very sunny, rainy or stormy
- Interactive dashboards with actual, current and future predicted data
- Region, source, time-window and parameter filters
- Configurable real-time alerts and anomaly resolution
- Support tickets and FAQ

### AI / ML Hub

Administrators can:

- Train multiple models
- Give every model a custom model name
- Give every model a custom file name
- Select Random Forest, Extra Trees, Gradient Boosting or Linear Regression
- Change hyperparameters through the JSON editor
- Select training region or all regions
- Choose validation holdout ratio
- Save trained Joblib files
- Inspect MAE, R² and feature importance
- Select the active model used by the forecasting/analysis screens

### UI and settings

- Climate-themed intro animation
- Loading bar
- CSS 3D climate globe/orb visual
- Dashboard animations
- Personal background, surface, text, accent and muted colors
- Font selection
- Density and motion controls
- Intro animation toggle
- Data defaults: region, history window, source, anomaly threshold, missing-data strategy and simulator interval

## Run

1. Create a Python virtual environment.
2. Install `requirements.txt`.
3. Copy `.env.example` to `.env` and adjust the MongoDB connection.
4. Ensure MongoDB is running.
5. Run `python seed.py` for a one-year six-region demo dataset and an initial saved multi-variable model.
6. Run `python app.py`.
7. Open `http://127.0.0.1:5000`.

Demo admin account: `admin` / `admin123`. Change the password for real use.

## Project verification

See `docs/REQUIREMENTS_MATRIX.md`, `docs/PROJECT_CHECK.md`, `docs/TEST_PLAN.md`, `docs/USER_GUIDE.md`, `docs/DEVELOPER_GUIDE.md` and `docs/VIDEO_DEMO_SCRIPT.md`.
