import os, json, threading, time, zipfile
from datetime import datetime, timezone
from services.db import db
from services.audit import log
from services.security import encrypt_text

COLLECTIONS=['users','datasets','climate_records','satellite_assets','anomalies','alerts','alert_rules','models','tickets','settings','audit_logs','metrics']

def run_backup(base_folder):
    os.makedirs(base_folder,exist_ok=True);stamp=datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S');dest=os.path.join(base_folder,stamp);os.makedirs(dest,exist_ok=True)
    manifest={'created_at':datetime.now(timezone.utc).isoformat(),'encrypted':bool(os.getenv('ENCRYPTION_KEY')),'collections':[]}
    for c in COLLECTIONS:
        data=list(db()[c].find({}, {'_id':0}));payload=json.dumps(data,default=str,indent=2)
        if os.getenv('ENCRYPTION_KEY'):
            with open(os.path.join(dest,c+'.json.enc'),'w',encoding='utf-8') as f:f.write(encrypt_text(payload))
        else:
            with open(os.path.join(dest,c+'.json'),'w',encoding='utf-8') as f:f.write(payload)
        manifest['collections'].append({'name':c,'records':len(data)})
    with open(os.path.join(dest,'manifest.json'),'w',encoding='utf-8') as f:json.dump(manifest,f,indent=2)
    db().backups.insert_one({'name':stamp,'created_at':datetime.now(timezone.utc),'path':dest,'status':'completed','encrypted':manifest['encrypted'],'records':manifest['collections']});log('backup_completed',details={'name':stamp,'encrypted':manifest['encrypted']})
    return dest

def start_scheduler(folder,hours):
    def loop():
        while True:
            try:run_backup(folder)
            except Exception as e:log('backup_failed',details={'error':str(e)},status='failed')
            time.sleep(max(60,hours*3600))
    t=threading.Thread(target=loop,daemon=True,name='earthscape-backup-scheduler');t.start();return t
