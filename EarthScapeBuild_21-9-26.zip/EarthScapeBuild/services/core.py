
import os
from datetime import datetime, timezone

import numpy as np
import pandas as pd

from services.db import db

ALIASES = {
    "date": "timestamp",
    "datetime": "timestamp",
    "time": "timestamp",
    "location": "region",
    "area": "region",
    "city": "region",
    "temp": "temperature",
    "temperature_c": "temperature",
    "rain": "rainfall",
    "rainfall_mm": "rainfall",
    "windspeed": "wind_speed",
    "wind_speed_kmh": "wind_speed",
    "humidity_pct": "humidity",
    "pressure_hpa": "pressure",
    "lat": "latitude",
    "lon": "longitude",
    "lng": "longitude",
}

NUMERIC_FIELDS = [
    "temperature",
    "humidity",
    "rainfall",
    "wind_speed",
    "pressure",
    "latitude",
    "longitude",
]

DATA_EXTENSIONS = {".csv", ".xlsx", ".json", ".geojson"}
IMAGE_EXTENSIONS = {".png", ".jpg", ".jpeg", ".tif", ".tiff"}


def normalize_columns(dataframe):
    renamed = {}

    for column in dataframe.columns:
        key = str(column).strip().lower().replace(" ", "_").replace("-", "_")
        renamed[column] = ALIASES.get(key, key)

    return dataframe.rename(columns=renamed)


def load_dataframe(path):
    extension = os.path.splitext(path)[1].lower()

    if extension == ".csv":
        return pd.read_csv(path)

    if extension == ".xlsx":
        return pd.read_excel(path)

    if extension in {".json", ".geojson"}:
        return pd.read_json(path)

    raise ValueError("Unsupported dataset format")


def validate_df(dataframe):
    data = normalize_columns(dataframe.copy())
    errors = []
    warnings = []

    for column in ["timestamp", "region"]:
        if column not in data.columns:
            errors.append(f"Missing required column: {column}")

    for column in ["temperature", "humidity", "rainfall", "wind_speed", "pressure"]:
        if column not in data.columns:
            continue

        raw_missing = int(data[column].isna().sum())
        parsed = pd.to_numeric(data[column], errors="coerce")
        invalid = int(parsed.isna().sum() - raw_missing)

        if invalid:
            warnings.append(
                f"{column}: {invalid} invalid numeric values will be repaired"
            )

        if raw_missing:
            warnings.append(f"{column}: {raw_missing} missing values detected")

    return {
        "valid": not errors,
        "rows": int(len(data)),
        "columns": list(data.columns),
        "errors": errors,
        "warnings": warnings,
    }


def clean(dataframe):
    data = normalize_columns(dataframe.copy())

    if "timestamp" not in data:
        data["timestamp"] = datetime.now(timezone.utc)

    data["timestamp"] = pd.to_datetime(
        data["timestamp"], errors="coerce", utc=True
    ).fillna(pd.Timestamp.now(tz="UTC"))

    if "region" not in data:
        data["region"] = "Unknown"

    data["region"] = data["region"].fillna("Unknown").astype(str)

    for column in NUMERIC_FIELDS:
        if column not in data:
            continue

        data[column] = pd.to_numeric(data[column], errors="coerce")
        median = data[column].median()

        if pd.notna(median):
            data[column] = data[column].fillna(median)

    return data.replace({np.nan: None})


def import_df(dataframe, name, source="weather_station", description=""):
    database = db()
    data = clean(dataframe)
    records = []

    for row in data.to_dict("records"):
        timestamp = row.get("timestamp")

        if hasattr(timestamp, "to_pydatetime"):
            row["timestamp"] = timestamp.to_pydatetime()

        row.update(
            {
                "dataset": name,
                "source_type": source,
                "ingested_at": datetime.now(timezone.utc),
            }
        )
        records.append(row)

    if records:
        database.climate_records.insert_many(records)

    database.datasets.insert_one(
        {
            "name": name,
            "source_type": source,
            "description": description,
            "records": len(records),
            "columns": list(data.columns),
            "created_at": datetime.now(timezone.utc),
        }
    )

    return len(records)


def import_file(path, name, source="weather_station", description=""):
    extension = os.path.splitext(path)[1].lower()

    if extension in DATA_EXTENSIONS:
        return import_df(load_dataframe(path), name, source, description)

    raise ValueError(
        "That file is an imagery format. Use the satellite image upload endpoint."
    )


def import_satellite_metadata(path, name, description=""):
    metadata = {
        "name": name,
        "source_type": "satellite_imagery",
        "description": description,
        "file_ext": os.path.splitext(path)[1].lower(),
        "size_bytes": os.path.getsize(path),
        "created_at": datetime.now(timezone.utc),
    }

    try:
        from PIL import Image

        image = Image.open(path)
        metadata.update(
            {
                "width": image.width,
                "height": image.height,
                "format": image.format,
                "mode": image.mode,
            }
        )
    except Exception:
        pass

    db().satellite_assets.insert_one(metadata)
    return metadata


def frame(limit=120000):
    records = list(
        db()
        .climate_records.find({}, {"_id": 0})
        .sort("timestamp", 1)
        .limit(limit)
    )

    if not records:
        return pd.DataFrame()

    data = pd.DataFrame(records)
    data["timestamp"] = pd.to_datetime(data["timestamp"], utc=True, errors="coerce")
    return data


def filtered_frame(region=None, start=None, end=None, source_type=None, limit=120000):
    query = {}

    if region:
        query["region"] = region

    if source_type:
        query["source_type"] = source_type

    if start or end:
        query["timestamp"] = {}

        if start:
            query["timestamp"]["$gte"] = pd.Timestamp(start, tz="UTC").to_pydatetime()

        if end:
            query["timestamp"]["$lte"] = pd.Timestamp(end, tz="UTC").to_pydatetime()

    records = list(
        db()
        .climate_records.find(query, {"_id": 0})
        .sort("timestamp", 1)
        .limit(limit)
    )

    if not records:
        return pd.DataFrame()

    data = pd.DataFrame(records)
    data["timestamp"] = pd.to_datetime(data["timestamp"], utc=True, errors="coerce")
    return data


def summary():
    data = frame()
    database = db()

    if data.empty:
        return {
            "records": 0,
            "regions": 0,
            "datasets": database.datasets.count_documents({}),
            "satellite_assets": database.satellite_assets.count_documents({}),
            "avg_temp": None,
            "min_temp": None,
            "max_temp": None,
            "rainfall": 0,
            "anomalies": database.anomalies.count_documents({"status": "active"}),
            "active_alerts": database.alerts.count_documents({"status": "active"}),
            "tickets": database.tickets.count_documents({"status": "open"}),
        }

    return {
        "records": len(data),
        "regions": int(data["region"].nunique()) if "region" in data else 0,
        "datasets": database.datasets.count_documents({}),
        "satellite_assets": database.satellite_assets.count_documents({}),
        "avg_temp": round(float(data.temperature.mean()), 2)
        if "temperature" in data
        else None,
        "min_temp": round(float(data.temperature.min()), 2)
        if "temperature" in data
        else None,
        "max_temp": round(float(data.temperature.max()), 2)
        if "temperature" in data
        else None,
        "rainfall": round(float(data.rainfall.sum()), 2)
        if "rainfall" in data
        else 0,
        "anomalies": database.anomalies.count_documents({"status": "active"}),
        "active_alerts": database.alerts.count_documents({"status": "active"}),
        "tickets": database.tickets.count_documents({"status": "open"}),
    }


def trend(days=60, region=None, source_type=None):
    data = filtered_frame(region=region, source_type=source_type)

    if data.empty or "temperature" not in data:
        return []

    series = (
        data.set_index("timestamp")["temperature"]
        .resample("D")
        .mean()
        .dropna()
        .tail(days)
    )

    return [
        {"date": date.strftime("%Y-%m-%d"), "value": round(float(value), 2)}
        for date, value in series.items()
    ]


def rainfall(days=60, region=None, source_type=None):
    data = filtered_frame(region=region, source_type=source_type)

    if data.empty or "rainfall" not in data:
        return []

    series = (
        data.set_index("timestamp")["rainfall"]
        .resample("D")
        .sum()
        .dropna()
        .tail(days)
    )

    return [
        {"date": date.strftime("%Y-%m-%d"), "value": round(float(value), 2)}
        for date, value in series.items()
    ]


def regions():
    data = frame()

    if data.empty:
        return []

    for column in ["temperature", "rainfall"]:
        if column not in data:
            data[column] = 0

    grouped = (
        data.groupby("region")
        .agg(
            records=("region", "size"),
            avg_temperature=("temperature", "mean"),
            rainfall=("rainfall", "sum"),
        )
        .reset_index()
    )

    return [
        {
            "region": row.region,
            "records": int(row.records),
            "avg_temperature": round(float(row.avg_temperature), 2),
            "rainfall": round(float(row.rainfall), 2),
        }
        for _, row in grouped.iterrows()
    ]


def correlations():
    data = frame()
    columns = [column for column in NUMERIC_FIELDS if column in data]

    if len(columns) < 2:
        return []

    correlation_matrix = data[columns].corr()
    results = []

    for index, first in enumerate(columns):
        for second in columns[index + 1 :]:
            value = correlation_matrix.loc[first, second]

            if pd.notna(value):
                results.append(
                    {
                        "a": first,
                        "b": second,
                        "value": round(float(value), 3),
                    }
                )

    return sorted(results, key=lambda item: abs(item["value"]), reverse=True)


def anomalies(threshold=None):
    data = frame()

    if data.empty or "temperature" not in data:
        return []

    standard_deviation = data.temperature.std()

    if not standard_deviation or pd.isna(standard_deviation):
        return []

    configured = db().settings.find_one({"key": "anomaly_z"})
    z_threshold = threshold if threshold is not None else (configured["value"] if configured else 2.5)

    data["score"] = (
        (data.temperature - data.temperature.mean()).abs() / standard_deviation
    )
    rows = data[data.score >= float(z_threshold)].tail(200)
    results = []

    for _, row in rows.iterrows():
        document = {
            "timestamp": row.timestamp,
            "region": row.region,
            "temperature": float(row.temperature),
            "score": round(float(row.score), 2),
            "status": "active",
            "type": "temperature",
            "created_at": datetime.now(timezone.utc),
        }

        exists = db().anomalies.find_one(
            {
                "timestamp": document["timestamp"],
                "region": document["region"],
                "temperature": document["temperature"],
            }
        )

        if not exists:
            db().anomalies.insert_one(document)

        results.append(document)

    return results
