
import re
from datetime import datetime, timezone
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, r2_score

from services.db import db
from services.core import filtered_frame

TARGETS = ["temperature", "humidity", "pressure", "wind_speed", "rainfall"]
LAGS = (1, 2, 3, 7, 14)
WINDOWS = (3, 7, 14)
MODEL_VERSION = "earthscape-weather-rf-v1"
MODEL_DIR = Path(__file__).resolve().parent.parent / "models"
MODEL_DIR.mkdir(parents=True, exist_ok=True)

DISPLAY_NAMES = {
    "temperature": "Temperature",
    "humidity": "Humidity",
    "pressure": "Pressure",
    "wind_speed": "Wind speed",
    "rainfall": "Rainfall",
}

UNITS = {
    "temperature": "°C",
    "humidity": "%",
    "pressure": "hPa",
    "wind_speed": "km/h",
    "rainfall": "mm",
}

CLIP_LIMITS = {
    "humidity": (0, 100),
    "rainfall": (0, None),
    "wind_speed": (0, None),
}


def _safe_slug(value):
    text = re.sub(r"[^a-z0-9]+", "_", value.lower()).strip("_")
    return text or "global"


def _model_path(region):
    return MODEL_DIR / f"weather_forecast_{_safe_slug(region)}.joblib"


def _daily_weather(region=None):
    data = filtered_frame(region=region, limit=250000)

    if data.empty or "timestamp" not in data:
        return pd.DataFrame()

    data["timestamp"] = pd.to_datetime(data["timestamp"], utc=True, errors="coerce")
    data = data.dropna(subset=["timestamp"])
    data = data.sort_values("timestamp")

    available = [column for column in TARGETS if column in data.columns]

    if len(available) < 3:
        return pd.DataFrame()

    data = data.set_index("timestamp")
    daily = pd.DataFrame(index=pd.date_range(data.index.min().floor("D"), data.index.max().floor("D"), freq="D", tz="UTC"))

    for column in available:
        if column == "rainfall":
            series = data[column].resample("D").sum(min_count=1)
        else:
            series = data[column].resample("D").mean()

        daily[column] = series.reindex(daily.index)

    for column in TARGETS:
        if column not in daily:
            daily[column] = np.nan

        daily[column] = pd.to_numeric(daily[column], errors="coerce")
        daily[column] = daily[column].interpolate(method="time").ffill().bfill()

    return daily[TARGETS].dropna()


def _feature_row(history, timestamp):
    features = {}

    # Lagged weather variables capture short-term persistence and changes.
    for column in TARGETS:
        for lag in LAGS:
            features[f"{column}_lag_{lag}"] = float(history[column].iloc[-lag])

        for window in WINDOWS:
            values = history[column].tail(window)
            features[f"{column}_mean_{window}"] = float(values.mean())
            features[f"{column}_std_{window}"] = float(values.std(ddof=0))

    day_of_year = timestamp.timetuple().tm_yday
    day_of_week = timestamp.dayofweek

    features["day_of_year_sin"] = np.sin(2 * np.pi * day_of_year / 365.25)
    features["day_of_year_cos"] = np.cos(2 * np.pi * day_of_year / 365.25)
    features["day_of_week_sin"] = np.sin(2 * np.pi * day_of_week / 7)
    features["day_of_week_cos"] = np.cos(2 * np.pi * day_of_week / 7)

    return features


def _training_set(daily):
    minimum_history = max(max(LAGS), max(WINDOWS))
    features = []
    targets = []

    for index in range(minimum_history, len(daily)):
        history = daily.iloc[:index]
        timestamp = daily.index[index]
        features.append(_feature_row(history, timestamp))
        targets.append(daily.iloc[index][TARGETS].to_dict())

    if not features:
        return pd.DataFrame(), pd.DataFrame()

    return pd.DataFrame(features), pd.DataFrame(targets)[TARGETS]


def _build_model():
    return RandomForestRegressor(
        n_estimators=300,
        max_depth=16,
        min_samples_leaf=2,
        max_features=0.75,
        random_state=42,
        n_jobs=-1,
    )


def _metrics(actual, predicted):
    results = {}

    for index, target in enumerate(TARGETS):
        results[target] = {
            "mae": round(float(mean_absolute_error(actual[:, index], predicted[:, index])), 3),
            "r2": round(float(r2_score(actual[:, index], predicted[:, index])), 3),
        }

    return results


def _store_metadata(region, daily, metrics, feature_count, holdout_rows, model):
    trained_at = datetime.now(timezone.utc)
    document = {
        "region": region,
        "model_version": MODEL_VERSION,
        "algorithm": "RandomForestRegressor (multi-output)",
        "trained_at": trained_at,
        "observations": int(len(daily)),
        "training_features": int(feature_count),
        "holdout_rows": int(holdout_rows),
        "metrics": metrics,
        "targets": TARGETS,
        "units": UNITS,
        "model_path": str(_model_path(region)),
        "hyperparameters": {
            "n_estimators": 300,
            "max_depth": 16,
            "min_samples_leaf": 2,
            "max_features": 0.75,
        },
        "top_features": sorted(
            [
                {"feature": name, "importance": round(float(score), 5)}
                for name, score in zip(model.feature_names_in_, model.feature_importances_)
            ],
            key=lambda item: item["importance"],
            reverse=True,
        )[:15],
    }

    db().forecast_models.update_one(
        {"region": region},
        {"$set": document},
        upsert=True,
    )

    return document


def train_region(region):
    daily = _daily_weather(region)

    if len(daily) < 30:
        return {
            "trained": False,
            "region": region,
            "message": "At least 30 daily observations are required for training.",
        }

    X, y = _training_set(daily)

    if len(X) < 20:
        return {
            "trained": False,
            "region": region,
            "message": "Not enough training windows were created from the available history.",
        }

    # Keep the newest observations as an unseen time-series holdout.
    split = max(10, int(len(X) * 0.8))
    split = min(split, len(X) - 1)

    validation_model = _build_model()
    validation_model.fit(X.iloc[:split], y.iloc[:split])
    validation_prediction = validation_model.predict(X.iloc[split:])
    validation_metrics = _metrics(y.iloc[split:].to_numpy(), validation_prediction)

    final_model = _build_model()
    final_model.fit(X, y)
    joblib.dump(final_model, _model_path(region))

    metadata = _store_metadata(
        region,
        daily,
        validation_metrics,
        len(X.columns),
        len(X) - split,
        final_model,
    )

    return {
        "trained": True,
        "region": region,
        "trained_at": metadata["trained_at"],
        "observations": metadata["observations"],
        "training_rows": len(X),
        "holdout_rows": metadata["holdout_rows"],
        "metrics": validation_metrics,
    }


def train_all_regions(region=None):
    if region:
        return [train_region(region)]

    regions = db().climate_records.distinct("region")
    results = []

    for item in sorted(regions):
        results.append(train_region(item))

    return results


def model_metadata(region):
    return db().forecast_models.find_one({"region": region}, {"_id": 0})


def _load_model(region):
    path = _model_path(region)

    if not path.exists():
        return None

    return joblib.load(path)


def _clip_prediction(target, value):
    lower, upper = CLIP_LIMITS.get(target, (None, None))

    if lower is not None:
        value = max(lower, value)

    if upper is not None:
        value = min(upper, value)

    return float(value)


def forecast_region(region, days=10):
    model = _load_model(region)
    metadata = model_metadata(region)
    history = _daily_weather(region)

    if model is None or not metadata:
        return {
            "trained": False,
            "region": region,
            "message": "No trained model exists for this region. Train the model first.",
            "history": _serialize_history(history.tail(180)),
            "forecast": [],
        }

    if history.empty or len(history) < max(LAGS):
        return {
            "trained": False,
            "region": region,
            "message": "Not enough recent weather history for forecasting.",
            "history": [],
            "forecast": [],
        }

    working = history.copy()
    predictions = []

    # Forecast recursively so every new predicted day becomes context for the next day.
    for step in range(1, days + 1):
        next_day = working.index[-1] + pd.Timedelta(days=1)
        row = pd.DataFrame([_feature_row(working, next_day)])
        prediction = model.predict(row)[0]
        values = {
            target: _clip_prediction(target, prediction[index])
            for index, target in enumerate(TARGETS)
        }

        values["date"] = next_day.strftime("%Y-%m-%d")
        predictions.append(values)
        working.loc[next_day, TARGETS] = [values[target] for target in TARGETS]

    current = _serialize_history(history.tail(1))[0] if not history.empty else None

    return {
        "trained": True,
        "region": region,
        "model": {
            "algorithm": metadata["algorithm"],
            "model_version": metadata["model_version"],
            "trained_at": metadata["trained_at"],
            "observations": metadata["observations"],
            "metrics": metadata["metrics"],
            "top_features": metadata.get("top_features", []),
        },
        "current": current,
        "history": _serialize_history(history.tail(180)),
        "forecast": predictions,
    }


def forecast_all_regions(days=10):
    regions = sorted(db().climate_records.distinct("region"))
    results = []

    for region in regions:
        result = forecast_region(region, days)
        if result.get("trained"):
            results.append(result)

    return results


def _serialize_history(data):
    if data.empty:
        return []

    output = []

    for timestamp, row in data.iterrows():
        item = {"date": timestamp.strftime("%Y-%m-%d")}

        for target in TARGETS:
            if target in row and pd.notna(row[target]):
                item[target] = round(float(row[target]), 3)
            else:
                item[target] = None

        output.append(item)

    return output


def _aggregate_forecast(results):
    if not results:
        return []

    output = []
    for index in range(len(results[0]["forecast"])):
        item = {"date": results[0]["forecast"][index]["date"]}

        for target in TARGETS:
            values = [result["forecast"][index][target] for result in results]
            item[target] = round(float(np.mean(values)), 3)

        output.append(item)

    return output


def forecast_bundle(region=None, history_days=90, forecast_days=10, source_type=None):
    if region:
        result = forecast_region(region, forecast_days)
        result["history"] = result.get("history", [])[-history_days:]
        result["history_days"] = history_days
        result["forecast_days"] = forecast_days
        result["source_filter"] = source_type or "all"

        if source_type:
            display_history = _daily_weather_filtered_for_display(region, source_type)
            result["history"] = _serialize_history(display_history.tail(history_days))

        return result

    trained_regions = forecast_all_regions(forecast_days)
    all_history = _daily_weather(None)

    if source_type:
        all_history = _daily_weather_filtered_for_display(None, source_type)

    current = _serialize_history(all_history.tail(1))[0] if not all_history.empty else None

    return {
        "trained": bool(trained_regions),
        "region": None,
        "message": None if trained_regions else "Train at least one regional model first.",
        "current": current,
        "history": _serialize_history(all_history.tail(history_days)),
        "forecast": _aggregate_forecast(trained_regions),
        "history_days": history_days,
        "forecast_days": forecast_days,
        "regions": [result["region"] for result in trained_regions],
        "models": [result.get("model") for result in trained_regions],
        "source_filter": source_type or "all",
    }


def _daily_weather_filtered_for_display(region, source_type):
    data = filtered_frame(region=region, source_type=source_type, limit=250000)

    if data.empty:
        return pd.DataFrame(columns=TARGETS)

    data["timestamp"] = pd.to_datetime(data["timestamp"], utc=True, errors="coerce")
    data = data.dropna(subset=["timestamp"]).set_index("timestamp")
    daily = pd.DataFrame(index=pd.date_range(data.index.min().floor("D"), data.index.max().floor("D"), freq="D", tz="UTC"))

    for target in TARGETS:
        if target not in data.columns:
            daily[target] = np.nan
            continue

        if target == "rainfall":
            series = data[target].resample("D").sum(min_count=1)
        else:
            series = data[target].resample("D").mean()

        daily[target] = series.reindex(daily.index)

    for target in TARGETS:
        daily[target] = pd.to_numeric(daily[target], errors="coerce")
        daily[target] = daily[target].interpolate(method="time").ffill().bfill()

    return daily.dropna(how="all")
