import os, base64
from cryptography.fernet import Fernet

_KEY=os.getenv('ENCRYPTION_KEY','')

def _fernet():
    if not _KEY:
        return None
    try:return Fernet(_KEY.encode())
    except Exception:return None

def encrypt_text(value):
    f=_fernet()
    if not f:return value
    return f.encrypt(str(value).encode()).decode()

def decrypt_text(value):
    f=_fernet()
    if not f:return value
    try:return f.decrypt(value.encode()).decode()
    except Exception:return value
