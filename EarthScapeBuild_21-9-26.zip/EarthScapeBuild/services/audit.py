from datetime import datetime, timezone
from services.db import db

def log(action, username=None, details=None, status='success'):
    try:
        db().audit_logs.insert_one({'timestamp':datetime.now(timezone.utc),'username':username,'action':action,'details':details or {},'status':status})
    except Exception: pass
