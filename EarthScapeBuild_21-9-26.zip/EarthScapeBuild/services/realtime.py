import threading, time, random
from services.core import ingest_live

def simulator_running(flag): return bool(flag.get('running'))

def run_simulator(flag):
    while flag.get('running'):
        ingest_live({'region':random.choice(['Lahore','Karachi','Islamabad','Rahim Yar Khan','Peshawar','Quetta']),'temperature':round(random.uniform(18,48),2),'humidity':round(random.uniform(20,90),2),'rainfall':round(max(0,random.gauss(8,18)),2),'wind_speed':round(random.uniform(2,40),2),'pressure':round(random.uniform(995,1025),2),'source_type':'realtime_simulation'})
        time.sleep(5)

def start(flag):
    if flag.get('running'):return
    flag['running']=True;threading.Thread(target=run_simulator,args=(flag,),daemon=True,name='earthscape-live-simulator').start()

def stop(flag):flag['running']=False
