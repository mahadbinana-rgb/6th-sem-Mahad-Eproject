from pymongo import MongoClient
from datetime import datetime, timezone
_db=None

def init_db(uri,name):
    global _db; _db=MongoClient(uri,serverSelectionTimeoutMS=3000)[name]
    for c in ['users','climate_records','datasets','satellite_assets','anomalies','alerts','tickets','alert_rules','models','metrics','backups','settings']:
        try:_db[c].create_index([('created_at',-1)])
        except Exception:pass
    _db.users.create_index('username',unique=True)
    _db.climate_records.create_index([('timestamp',-1)])
    _db.climate_records.create_index('region')
    _db.climate_records.create_index([('source_type',1),('timestamp',-1)])
    _db.climate_records.create_index([('region',1),('timestamp',-1)])
    if not _db.settings.find_one({'key':'anomaly_z'}): _db.settings.insert_one({'key':'anomaly_z','value':2.5})
    if not _db.alert_rules.count_documents({}):
        _db.alert_rules.insert_many([
            {'name':'Extreme Temperature','field':'temperature','operator':'>=','threshold':45,'severity':'high','enabled':True},
            {'name':'Extreme Rainfall','field':'rainfall','operator':'>=','threshold':150,'severity':'high','enabled':True}
        ])

def db(): return _db
