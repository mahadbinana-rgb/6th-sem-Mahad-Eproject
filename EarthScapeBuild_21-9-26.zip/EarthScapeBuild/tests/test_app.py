import os
os.environ['MONGO_URI']='mongodb://127.0.0.1:27017/'
os.environ['MONGO_DB']='earthscape_test'
from app import app

def test_health_route():
    client=app.test_client()
    r=client.get('/health')
    assert r.status_code in (200,503)
