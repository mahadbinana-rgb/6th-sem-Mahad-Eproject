import os, tempfile
import pandas as pd
from services.core import validate_df, clean

def test_validate_and_clean_missing_values():
    df=pd.DataFrame({'timestamp':['2026-09-01'],'region':['Test'],'temperature':[None],'rainfall':['bad']})
    result=validate_df(df)
    assert result['valid'] is True
    assert result['warnings']
    cleaned=clean(df)
    assert 'timestamp' in cleaned.columns
    assert cleaned['region'].iloc[0]=='Test'
