import os
from dotenv import load_dotenv
load_dotenv()
BASE_DIR=os.path.dirname(os.path.abspath(__file__))
SECRET_KEY=os.getenv('SECRET_KEY','change-this-secret-key')
MONGO_URI=os.getenv('MONGO_URI','mongodb://localhost:27017/')
MONGO_DB=os.getenv('MONGO_DB','earthscape')
UPLOAD_FOLDER=os.path.join(BASE_DIR,'uploads')
BACKUP_FOLDER=os.path.join(BASE_DIR,'backups')
AUTO_BACKUP_ENABLED=os.getenv('AUTO_BACKUP_ENABLED','true').lower()=='true'
AUTO_BACKUP_HOURS=int(os.getenv('AUTO_BACKUP_HOURS','24'))
SSL_ENABLED=os.getenv('SSL_ENABLED','false').lower()=='true'
SSL_CERT=os.getenv('SSL_CERT','')
SSL_KEY=os.getenv('SSL_KEY','')
