import os
from flask import Flask
from config import *
from services.db import init_db
from routes.auth import bp as auth
from routes.main import bp as main
from routes.api import bp as api
from routes.admin import bp as admin
from middleware import install_metrics
from services.backup_service import start_scheduler

app=Flask(__name__)
app.secret_key=SECRET_KEY
app.config.update(UPLOAD_FOLDER=UPLOAD_FOLDER,BACKUP_FOLDER=BACKUP_FOLDER)
os.makedirs(UPLOAD_FOLDER,exist_ok=True);os.makedirs(BACKUP_FOLDER,exist_ok=True)
init_db(MONGO_URI,MONGO_DB)
app.register_blueprint(auth);app.register_blueprint(main);app.register_blueprint(api);app.register_blueprint(admin)
install_metrics(app)
if AUTO_BACKUP_ENABLED and os.environ.get('FLASK_RUN_FROM_CLI')!='true': start_scheduler(BACKUP_FOLDER,AUTO_BACKUP_HOURS)

if __name__=='__main__':
    kwargs={'host':'0.0.0.0','port':int(os.getenv('PORT','5000')),'debug':False}
    if SSL_ENABLED and SSL_CERT and SSL_KEY: kwargs['ssl_context']=(SSL_CERT,SSL_KEY)
    app.run(**kwargs)
