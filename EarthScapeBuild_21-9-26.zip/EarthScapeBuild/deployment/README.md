# Deployment, reliability and horizontal scaling

EarthScape keeps the Flask application stateless apart from MongoDB-backed data and uses one shared SECRET_KEY across replicas. This allows multiple Flask processes/instances to sit behind a reverse proxy/load balancer.

For transport security, set SSL_ENABLED=true with a certificate/key, or terminate TLS at the reverse proxy. Do not expose the local development server directly to the public internet.

For 99% uptime targets, run multiple application instances, health-check `/health`, and route traffic only to healthy instances. Schedule maintenance in advance. The project itself cannot guarantee an uptime percentage; the target depends on the deployment environment.

MongoDB should use a replica set for production fault tolerance. For very large datasets, MongoDB sharding can be introduced using a suitable shard key such as region/time; the current application already stores region, source type and timestamp fields and has indexes for these access patterns.
