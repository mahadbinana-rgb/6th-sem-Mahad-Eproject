
from services.forecasting import train_all_regions


if __name__ == "__main__":
    results = train_all_regions()

    for result in results:
        region = result.get("region")

        if result.get("trained"):
            print(f"{region}: trained successfully")
            print(f"  observations: {result['observations']}")
            print(f"  training rows: {result['training_rows']}")
            print(f"  holdout rows: {result['holdout_rows']}")
        else:
            print(f"{region}: {result.get('message', 'training failed')}")
