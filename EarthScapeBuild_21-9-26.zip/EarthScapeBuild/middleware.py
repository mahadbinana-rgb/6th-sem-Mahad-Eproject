import time
from datetime import datetime, timezone
from flask import request
from services.db import db

def install_metrics(app):
    @app.before_request
    def start_timer(): request._earthscape_start=time.perf_counter()
    @app.after_request
    def record_metrics(response):
        try:
            elapsed=(time.perf_counter()-request._earthscape_start)*1000
            db().metrics.insert_one({'timestamp':datetime.now(timezone.utc),'method':request.method,'path':request.path,'status':response.status_code,'duration_ms':round(elapsed,2)})
        except Exception: pass
        return response
