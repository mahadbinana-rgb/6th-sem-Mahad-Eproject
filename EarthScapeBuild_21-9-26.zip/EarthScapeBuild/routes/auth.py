from flask import Blueprint,render_template,request,redirect,url_for,session,flash
from werkzeug.security import generate_password_hash,check_password_hash
from services.db import db
from services.audit import log
from functools import wraps
bp=Blueprint('auth',__name__)
@bp.route('/login',methods=['GET','POST'])
def login():
    if request.method=='POST':
        u=db().users.find_one({'username':request.form.get('username','').strip()})
        if u and check_password_hash(u['password'],request.form.get('password','')):
            session.clear();session.update(username=u['username'],role=u['role']);log('login',u['username']);return redirect('/')
        log('login_failed',request.form.get('username',''),status='failed');flash('Invalid username or password.','danger')
    return render_template('login.html')
@bp.route('/register',methods=['GET','POST'])
def register():
    if request.method=='POST':
        username=request.form.get('username','').strip(); password=request.form.get('password','')
        if len(username)<3 or len(password)<6: flash('Username must be 3+ characters and password 6+ characters.','warning')
        elif db().users.find_one({'username':username}): flash('Username already exists.','danger')
        else: db().users.insert_one({'username':username,'password':generate_password_hash(password),'role':'analyst','created_at':__import__('datetime').datetime.now(__import__('datetime').timezone.utc)});flash('Account created.','success');return redirect('/login')
    return render_template('register.html')
@bp.get('/logout')
def logout():session.clear();return redirect('/login')
def required(f):
 @wraps(f)
 def w(*a,**k):return f(*a,**k) if session.get('username') else redirect('/login')
 return w
def role_required(*roles):
 def deco(f):
  @wraps(f)
  def w(*a,**k):
   if not session.get('username'): return redirect('/login')
   if session.get('role') not in roles: flash('Administrator access required.','danger'); return redirect('/')
   return f(*a,**k)
  return w
 return deco
