
from flask import Blueprint, jsonify, request, session

from routes.auth import required, role_required
from services.audit import log
from services.core import anomalies, correlations, rainfall, regions, summary, trend
from services.db import db
from services.forecasting import forecast_bundle, train_all_regions
from services.realtime import start, stop

bp = Blueprint("api", __name__, url_prefix="/api")
SIM = {"running": False}


@bp.get("/analytics")
@required
def analytics():
    region = request.args.get("region") or None
    days = max(7, min(int(request.args.get("days", 60)), 365))
    source_type = request.args.get("source") or None

    return jsonify(
        {
            "summary": summary(),
            "trend": trend(days, region, source_type),
            "rainfall": rainfall(days, region, source_type),
            "regions": regions(),
            "correlations": correlations(),
            "anomalies": anomalies(),
            "forecast": forecast_bundle(region, days, 10, source_type),
        }
    )


@bp.get("/forecast/full")
@required
def full_forecast():
    region = request.args.get("region") or None
    history_days = max(14, min(int(request.args.get("history_days", 90)), 365))
    return jsonify(
        forecast_bundle(
            region=region,
            history_days=history_days,
            forecast_days=10,
            source_type=request.args.get("source") or None,
        )
    )


@bp.post("/realtime")
@required
def realtime_api():
    payload = request.get_json() or {}
    from services.core import import_df

    fired = []
    try:
        fired = _ingest_live(payload)
    except Exception as exc:
        return jsonify({"ok": False, "error": str(exc)}), 400

    log(
        "realtime_ingestion",
        session.get("username"),
        {"alerts": len(fired)},
    )
    return jsonify({"alerts": fired, "ok": True})


@bp.post("/realtime/start")
@role_required("admin")
def realtime_start():
    start(SIM)
    return jsonify({"running": True})


@bp.post("/realtime/stop")
@role_required("admin")
def realtime_stop():
    stop(SIM)
    return jsonify({"running": False})


@bp.get("/realtime/status")
@required
def realtime_status():
    return jsonify({"running": SIM["running"]})


@bp.post("/models/train")
@role_required("admin")
def train_models():
    payload = request.get_json(silent=True) or {}
    region = payload.get("region") or None
    results = train_all_regions(region)
    log("models_trained", session.get("username"), {"region": region, "models": len(results)})
    return jsonify({"ok": True, "results": results})


@bp.get("/models")
@required
def models():
    return jsonify(
        list(db().forecast_models.find({}, {"_id": 0}).sort("trained_at", -1))
    )


@bp.get("/system")
@role_required("admin")
def system():
    import platform

    try:
        import psutil

        cpu = psutil.cpu_percent(interval=0.05)
        memory = psutil.virtual_memory().percent
        disk = psutil.disk_usage("/").percent
    except Exception:
        cpu = memory = disk = None

    metrics = list(
        db()
        .metrics.find({}, {"_id": 0})
        .sort("timestamp", -1)
        .limit(100)
    )
    average = (
        round(
            sum(item.get("duration_ms", 0) for item in metrics) / len(metrics),
            2,
        )
        if metrics
        else 0
    )

    return jsonify(
        {
            "platform": platform.platform(),
            "python": platform.python_version(),
            "cpu_percent": cpu,
            "memory_percent": memory,
            "disk_percent": disk,
            "recent_request_count": len(metrics),
            "avg_response_ms": average,
        }
    )


def _ingest_live(payload):
    from services.core import import_df

    from datetime import datetime, timezone

    values = {
        "timestamp": datetime.now(timezone.utc),
        "region": payload.get("region", "Live Station"),
        "temperature": payload.get("temperature"),
        "humidity": payload.get("humidity"),
        "pressure": payload.get("pressure"),
        "wind_speed": payload.get("wind_speed"),
        "rainfall": payload.get("rainfall"),
        "latitude": payload.get("latitude"),
        "longitude": payload.get("longitude"),
        "source_type": "realtime",
        "dataset": "realtime",
    }

    for key in ["temperature", "humidity", "pressure", "wind_speed", "rainfall", "latitude", "longitude"]:
        if values[key] is not None:
            try:
                values[key] = float(values[key])
            except (TypeError, ValueError):
                values[key] = None

    database = db()
    database.climate_records.insert_one(values)

    alerts = []
    for rule in database.alert_rules.find({"enabled": True}):
        field = rule.get("field")
        value = values.get(field)
        if not isinstance(value, (int, float)):
            continue

        operator = rule.get("operator")
        threshold = float(rule.get("threshold", 0))
        triggered = (
            (operator == ">" and value > threshold)
            or (operator == ">=" and value >= threshold)
            or (operator == "<" and value < threshold)
            or (operator == "<=" and value <= threshold)
        )

        if triggered:
            alert = {
                "type": rule["name"],
                "severity": rule.get("severity", "medium"),
                "message": f"{field} {value} triggered {rule['name']} ({operator} {threshold})",
                "region": values["region"],
                "status": "active",
                "created_at": values["timestamp"],
                "rule": rule["name"],
            }
            database.alerts.insert_one(alert)
            alerts.append(alert)

    return alerts
