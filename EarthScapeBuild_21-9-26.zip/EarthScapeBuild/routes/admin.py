
from flask import Blueprint, current_app, flash, redirect, render_template, request, session

from routes.auth import role_required
from services.audit import log
from services.backup_service import run_backup
from services.db import db
from services.forecasting import train_all_regions

bp = Blueprint("admin", __name__, url_prefix="/admin")


@bp.get("/")
@role_required("admin")
def index():
    database = db()

    stats = {
        "users": database.users.count_documents({}),
        "records": database.climate_records.count_documents({}),
        "datasets": database.datasets.count_documents({}),
        "satellite_assets": database.satellite_assets.count_documents({}),
        "alerts": database.alerts.count_documents({"status": "active"}),
        "tickets": database.tickets.count_documents({"status": "open"}),
        "metrics": database.metrics.count_documents({}),
    }

    return render_template(
        "admin.html",
        stats=stats,
        regions=sorted(database.climate_records.distinct("region")),
        rules=list(database.alert_rules.find({}, {"_id": 0}).sort("name", 1)),
        users=list(
            database.users.find({}, {"_id": 0, "password": 0}).sort("username", 1)
        ),
        models=list(
            database.forecast_models.find({}, {"_id": 0}).sort("trained_at", -1)
        ),
        metrics=list(
            database.metrics.find({}, {"_id": 0}).sort("timestamp", -1).limit(12)
        ),
        backups=list(
            database.backups.find({}, {"_id": 0}).sort("created_at", -1).limit(10)
        ),
    )


@bp.post("/users/<username>/role")
@role_required("admin")
def set_role(username):
    requested = request.form.get("role", "analyst")
    role = requested if requested in {"admin", "analyst"} else "analyst"

    db().users.update_one({"username": username}, {"$set": {"role": role}})
    log(
        "role_changed",
        session.get("username"),
        {"target": username, "role": role},
    )
    flash("Role updated.", "success")
    return redirect("/admin")


@bp.post("/rules")
@role_required("admin")
def add_rule():
    name = request.form.get("name", "").strip()
    field = request.form.get("field", "").strip()
    operator = request.form.get("operator", ">=")
    severity = request.form.get("severity", "medium")

    try:
        threshold = float(request.form.get("threshold"))
    except (TypeError, ValueError):
        threshold = 0

    allowed_fields = {"temperature", "humidity", "rainfall", "wind_speed", "pressure"}
    allowed_operators = {">", ">=", "<", "<="}

    if name and field in allowed_fields and operator in allowed_operators:
        db().alert_rules.update_one(
            {"name": name},
            {
                "$set": {
                    "name": name,
                    "field": field,
                    "operator": operator,
                    "threshold": threshold,
                    "severity": severity,
                    "enabled": True,
                }
            },
            upsert=True,
        )
        log("alert_rule_saved", session.get("username"), {"name": name})
        flash("Alert rule saved.", "success")

    return redirect("/admin")


@bp.post("/rules/<name>/toggle")
@role_required("admin")
def toggle_rule(name):
    rule = db().alert_rules.find_one({"name": name})

    if rule:
        db().alert_rules.update_one(
            {"_id": rule["_id"]},
            {"$set": {"enabled": not rule.get("enabled", True)}},
        )

    return redirect("/admin")


@bp.post("/train")
@role_required("admin")
def train():
    region = request.form.get("region") or None
    results = train_all_regions(region)
    successful = sum(1 for result in results if result.get("trained"))

    if successful:
        flash(f"Trained/refreshed {successful} weather forecast model(s).", "success")
    else:
        flash(
            "No model was trained. Each region needs at least 30 daily observations.",
            "danger",
        )

    return redirect("/admin")


@bp.post("/backup")
@role_required("admin")
def backup():
    try:
        run_backup(current_app.config["BACKUP_FOLDER"])
        flash("Backup completed.", "success")
    except Exception as exc:
        flash(f"Backup failed: {exc}", "danger")

    return redirect("/admin")
