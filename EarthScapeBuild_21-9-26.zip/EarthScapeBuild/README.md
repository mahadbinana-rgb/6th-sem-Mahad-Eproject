
# EarthScape Climate Intelligence — V3

Flask + MongoDB + HTML/CSS + vanilla JavaScript.

## AI forecasting upgrade

EarthScape now uses a trainable multi-variable weather forecasting pipeline instead of a temperature-only regression.

The model:

- Trains one model per region.
- Uses the full stored weather history.
- Learns temperature, humidity, pressure, wind speed and rainfall together.
- Uses lagged weather variables, rolling means/std-devs and calendar seasonality features.
- Keeps the newest observations as a chronological holdout for model metrics.
- Saves trained models to `models/*.joblib`.
- Supports explicit retraining from the Administration or Analytics pages.
- Recursively forecasts the next **10 days** so previous predictions become context for later days.

## Analytics page

The Analytics page now combines:

- Historical daily observations
- Latest current observed values
- Full 10-day AI forecast
- Filters for region, history window and source
- Parameter filters for all five forecast variables
- Separate detailed charts for each variable
- Forecast table for all five variables across 10 days
- Model MAE and R² metrics
- Correlation analysis and anomaly results

## Run

```bash
python -m venv .venv
# Windows
.venv\\Scripts\\activate
pip install -r requirements.txt
copy .env.example .env
python seed.py
python app.py
```

Open `http://127.0.0.1:5000`.

Demo admin: `admin` / `admin123`

For manual retraining later:

```bash
python train_models.py
```

No React, Node.js, Hadoop, HDFS, MapReduce or Impala are used.
