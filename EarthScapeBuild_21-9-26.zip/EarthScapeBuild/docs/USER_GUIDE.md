# EarthScape User Guide

## Analyst

1. Register or sign in.
2. Open Data Center.
3. Select a source type: weather station, environmental sensor, satellite dataset, or historical climate dataset.
4. Upload CSV/XLSX/JSON/GeoJSON data. Satellite imagery files can be registered as imagery assets.
5. Use Advanced Analytics to filter by region and review temperature, rainfall, correlations, anomalies and forecasts.
6. Use Live Monitor to transmit a real-time observation.
7. Review Alerts & Anomalies and contact Support when needed.

## Administrator

Administrators additionally have access to Administration.

- Change user roles.
- Create/update and enable/disable alert rules.
- Train/refresh the predictive model.
- Review system request metrics and resource metrics through the admin API.
- Run manual backups. Automatic backups run at the configured interval.
- Start the real-time simulator for demonstration/testing.

## FAQ

**How are missing values handled?** Numeric missing values are filled with a dataset median where possible.

**How are anomalies detected?** Temperature values are scored against the dataset standard deviation using a configurable z-score threshold.

**How are forecasts produced?** The baseline model is linear regression over daily average temperature. It reports MAE, R² and trend direction.
