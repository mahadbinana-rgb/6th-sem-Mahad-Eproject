
# Developer Guide — AI Forecasting V3

## Forecasting architecture

The multi-variable model lives in `services/forecasting.py`.

### Training flow

1. Read stored climate observations from MongoDB.
2. Aggregate observations into daily weather values.
3. Repair missing daily values through time interpolation and forward/backward filling.
4. Build lag and rolling-statistic features.
5. Add seasonal calendar features.
6. Hold out the newest 20% of training windows for chronological evaluation.
7. Train a multi-output `RandomForestRegressor`.
8. Calculate MAE and R² separately for each target variable.
9. Refit on the full training window.
10. Save the model with Joblib and store metadata in MongoDB.

### Forecast flow

The saved model starts from the latest observed daily history and predicts one day at a time. Each predicted day is appended to the working history before the next prediction is created.

Targets:

- temperature
- humidity
- pressure
- wind_speed
- rainfall

Forecast horizon: 10 days.

## Main API endpoints

- `GET /api/forecast/full`
- `GET /api/models`
- `POST /api/models/train` (admin)
- `GET /api/analytics`

## Model files

Saved models use region-based filenames in `models/`. They should not be committed to source control for production. They can be regenerated with `python train_models.py`.
