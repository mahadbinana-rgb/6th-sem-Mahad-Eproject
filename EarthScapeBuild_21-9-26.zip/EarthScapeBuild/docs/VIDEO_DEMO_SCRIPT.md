# Demonstration Video Script

1. Start MongoDB and the Flask app.
2. Open the login page and sign in as the seeded administrator.
3. Show the dashboard metrics, temperature chart and forecast.
4. Open Data Center, select Weather Station, upload the demo CSV and show validation/import.
5. Show Regional Analytics and correlation results.
6. Show anomalies and alert rules.
7. Train/refresh the model from Administration and show MAE/R².
8. Open Live Monitor and transmit a normal observation.
9. Transmit an extreme temperature or rainfall observation and show the alert.
10. Start the live simulator from the admin API/UI if desired and refresh analytics.
11. Open Support and create a ticket.
12. Open Administration and show performance metrics, backup history, users/roles and model history.
13. Explain that automatic backups are enabled and that the project can be deployed behind a load balancer.
