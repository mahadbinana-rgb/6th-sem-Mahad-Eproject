
# Test Plan — AI Forecasting V3

## Data and training

1. Seed the demo data.
2. Log in as admin.
3. Open Analytics.
4. Train all regional models.
5. Confirm that each model reports observations and target-level MAE/R² metrics.

## Forecast checks

1. Confirm the forecast contains exactly 10 future dates.
2. Confirm every forecast date is one day after the previous date.
3. Confirm every forecast row includes temperature, humidity, pressure, wind speed and rainfall.
4. Compare the last historical date against the first forecast date in each chart.
5. Change the region filter and confirm the history/model/forecast changes.
6. Change the historical window and confirm the chart history changes.
7. Toggle parameter checkboxes and confirm only selected charts remain visible.
8. Use the source filter and confirm historical display changes while the stored regional model remains the training basis.

## Accuracy and behavior

- MAE is reported in each variable's native unit.
- R² is calculated on a chronological holdout.
- Humidity is clipped to 0–100%.
- Rainfall and wind speed are prevented from becoming negative.
- Retraining after new data is ingested refreshes the saved models.
