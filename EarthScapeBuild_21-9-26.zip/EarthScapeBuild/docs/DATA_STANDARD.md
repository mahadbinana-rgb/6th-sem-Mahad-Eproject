# Climate data conventions

EarthScape normalizes imported records around these conventions:

- `timestamp`: UTC date/time; ISO-8601 values are accepted.
- `region`: stable human-readable location name.
- `latitude` / `longitude`: decimal degrees, intended for WGS84 geographic coordinates.
- `temperature`: degrees Celsius in the application analytics layer.
- `rainfall`: millimetres.
- `wind_speed`: numeric speed value; the source unit should be documented by the dataset description.
- `pressure`: hPa when the source follows the application's pressure field convention.

The ingestion pipeline validates required fields, coerces numeric values, repairs missing numeric values where a median is available, and stores the original source type.
