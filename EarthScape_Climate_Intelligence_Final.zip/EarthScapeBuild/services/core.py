import os, json, time, math
from datetime import datetime, timezone, timedelta
import pandas as pd
import numpy as np
from services.db import db
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, r2_score

ALIASES={'date':'timestamp','datetime':'timestamp','time':'timestamp','location':'region','area':'region','city':'region','temp':'temperature','temperature_c':'temperature','rain':'rainfall','rainfall_mm':'rainfall','windspeed':'wind_speed','wind_speed_kmh':'wind_speed','humidity_pct':'humidity','pressure_hpa':'pressure','lat':'latitude','lon':'longitude','lng':'longitude'}
NUM=['temperature','humidity','rainfall','wind_speed','pressure','latitude','longitude']
DATA_EXT={'.csv','.xlsx','.json','.geojson'}
IMAGE_EXT={'.png','.jpg','.jpeg','.tif','.tiff'}

def normalize_columns(df):
    out={}
    for x in df.columns:
        k=str(x).strip().lower().replace(' ','_').replace('-','_')
        out[x]=ALIASES.get(k,k)
    return df.rename(columns=out)

def load_dataframe(path):
    ext=os.path.splitext(path)[1].lower()
    if ext=='.csv': return pd.read_csv(path)
    if ext=='.xlsx': return pd.read_excel(path)
    if ext in {'.json','.geojson'}: return pd.read_json(path)
    raise ValueError('Unsupported dataset format')

def validate_df(df):
    d=normalize_columns(df.copy()); errors=[]; warnings=[]
    for c in ['timestamp','region']:
        if c not in d.columns: errors.append(f'Missing required column: {c}')
    for c in ['temperature','humidity','rainfall','wind_speed','pressure']:
        if c in d.columns:
            raw=d[c].isna().sum(); parsed=pd.to_numeric(d[c],errors='coerce'); bad=int(parsed.isna().sum()-raw)
            if bad: warnings.append(f'{c}: {bad} invalid numeric values will be repaired')
            if parsed.isna().sum(): warnings.append(f'{c}: {int(parsed.isna().sum())} missing values detected')
    return {'valid':not errors,'rows':int(len(d)),'columns':list(d.columns),'errors':errors,'warnings':warnings}

def clean(df):
    df=normalize_columns(df.copy())
    if 'timestamp' not in df: df['timestamp']=datetime.now(timezone.utc)
    df['timestamp']=pd.to_datetime(df['timestamp'],errors='coerce',utc=True).fillna(pd.Timestamp.now(tz='UTC'))
    if 'region' not in df: df['region']='Unknown'
    df['region']=df['region'].fillna('Unknown').astype(str)
    for c in NUM:
        if c in df:
            df[c]=pd.to_numeric(df[c],errors='coerce')
            med=df[c].median()
            if pd.notna(med): df[c]=df[c].fillna(med)
    return df.replace({np.nan:None})

def import_df(df,name,source='weather_station',description=''):
    dbi=db(); df=clean(df); rec=[]
    for r in df.to_dict('records'):
        r['timestamp']=r['timestamp'].to_pydatetime() if hasattr(r['timestamp'],'to_pydatetime') else r['timestamp']
        r.update(dataset=name,source_type=source,ingested_at=datetime.now(timezone.utc))
        rec.append(r)
    if rec: dbi.climate_records.insert_many(rec)
    dbi.datasets.insert_one({'name':name,'source_type':source,'description':description,'records':len(rec),'columns':list(df.columns),'created_at':datetime.now(timezone.utc)})
    return len(rec)

def import_file(path,name,source='weather_station',description=''):
    ext=os.path.splitext(path)[1].lower()
    if ext in DATA_EXT: return import_df(load_dataframe(path),name,source,description)
    raise ValueError('That file is an imagery format. Use the imagery upload endpoint.')

def import_satellite_metadata(path,name,description=''):
    meta={'name':name,'source_type':'satellite_imagery','description':description,'file_ext':os.path.splitext(path)[1].lower(),'size_bytes':os.path.getsize(path),'created_at':datetime.now(timezone.utc)}
    try:
        from PIL import Image
        im=Image.open(path); meta.update({'width':im.width,'height':im.height,'format':im.format,'mode':im.mode})
    except Exception: pass
    db().satellite_assets.insert_one(meta)
    return meta

def frame(limit=120000):
    return pd.DataFrame(list(db().climate_records.find({}, {'_id':0}).sort('timestamp',1).limit(limit)))

def filtered_frame(region=None,start=None,end=None):
    q={}
    if region: q['region']=region
    if start or end:
        q['timestamp']={}
        if start: q['timestamp']['$gte']=pd.Timestamp(start,tz='UTC').to_pydatetime()
        if end: q['timestamp']['$lte']=pd.Timestamp(end,tz='UTC').to_pydatetime()
    return pd.DataFrame(list(db().climate_records.find(q,{'_id':0}).sort('timestamp',1).limit(120000)))

def summary():
    d=frame(); b=db()
    return {'records':len(d),'regions':int(d.region.nunique()) if not d.empty and 'region' in d else 0,'datasets':b.datasets.count_documents({}),'satellite_assets':b.satellite_assets.count_documents({}),'avg_temp':round(float(d.temperature.mean()),2) if not d.empty and 'temperature' in d else None,'min_temp':round(float(d.temperature.min()),2) if not d.empty and 'temperature' in d else None,'max_temp':round(float(d.temperature.max()),2) if not d.empty and 'temperature' in d else None,'rainfall':round(float(d.rainfall.sum()),2) if not d.empty and 'rainfall' in d else 0,'anomalies':b.anomalies.count_documents({'status':'active'}),'active_alerts':b.alerts.count_documents({'status':'active'}),'tickets':b.tickets.count_documents({'status':'open'})}

def trend(days=60,region=None):
    d=filtered_frame(region=region)
    if d.empty or 'temperature' not in d:return []
    d['timestamp']=pd.to_datetime(d.timestamp,utc=True); x=d.set_index('timestamp').temperature.resample('D').mean().dropna().tail(days)
    return [{'date':a.strftime('%Y-%m-%d'),'value':round(float(b),2)} for a,b in x.items()]

def rainfall(days=60,region=None):
    d=filtered_frame(region=region)
    if d.empty or 'rainfall' not in d:return []
    d['timestamp']=pd.to_datetime(d.timestamp,utc=True); x=d.set_index('timestamp').rainfall.resample('D').sum().dropna().tail(days)
    return [{'date':a.strftime('%Y-%m-%d'),'value':round(float(b),2)} for a,b in x.items()]

def regions():
    d=frame()
    if d.empty:return []
    for c in ['temperature','rainfall']:
        if c not in d:d[c]=0
    g=d.groupby('region').agg(records=('region','size'),avg_temperature=('temperature','mean'),rainfall=('rainfall','sum')).reset_index()
    return [{'region':r.region,'records':int(r.records),'avg_temperature':round(float(r.avg_temperature),2),'rainfall':round(float(r.rainfall),2)} for _,r in g.iterrows()]

def correlations():
    d=frame(); cols=[c for c in NUM if c in d]
    if len(cols)<2:return []
    c=d[cols].corr();out=[]
    for i,a in enumerate(cols):
        for b in cols[i+1:]:
            v=c.loc[a,b]
            if pd.notna(v):out.append({'a':a,'b':b,'value':round(float(v),3)})
    return sorted(out,key=lambda x:abs(x['value']),reverse=True)

def anomalies(threshold=None):
    d=frame()
    if d.empty or 'temperature' not in d:return []
    std=d.temperature.std();
    if not std or pd.isna(std):return []
    z=float(threshold if threshold is not None else db().settings.find_one({'key':'anomaly_z'})['value'] if db().settings.find_one({'key':'anomaly_z'}) else 2.5)
    d['score']=(d.temperature-d.temperature.mean()).abs()/std; rows=d[d.score>=z].tail(200);out=[]
    for _,r in rows.iterrows():
        doc={'timestamp':r.timestamp,'region':r.region,'temperature':float(r.temperature),'score':round(float(r.score),2),'status':'active','type':'temperature','created_at':datetime.now(timezone.utc)}
        if not db().anomalies.find_one({'timestamp':doc['timestamp'],'region':doc['region'],'temperature':doc['temperature']}):db().anomalies.insert_one(doc)
        out.append(doc)
    return out

def train_model(region=None):
    d=filtered_frame(region=region)
    if d.empty or 'temperature' not in d:return {'trained':False,'message':'Not enough climate data'}
    d['timestamp']=pd.to_datetime(d.timestamp,utc=True); x=d.set_index('timestamp').temperature.resample('D').mean().dropna()
    if len(x)<5:return {'trained':False,'message':'At least 5 daily observations are required'}
    X=np.arange(len(x)).reshape(-1,1); y=x.values; model=LinearRegression().fit(X,y); fitted=model.predict(X)
    doc={'model':'linear_regression','region':region or '*','trained_at':datetime.now(timezone.utc),'observations':len(x),'mae':float(mean_absolute_error(y,fitted)),'r2':float(r2_score(y,fitted)),'daily_change':float(model.coef_[0]),'intercept':float(model.intercept_)}
    db().models.update_one({'model':'linear_regression','region':region or '*'}, {'$set':doc}, upsert=True)
    return {'trained':True,'mae':round(doc['mae'],3),'r2':round(doc['r2'],3),'daily_change':round(doc['daily_change'],4),'trained_at':doc['trained_at']}

def forecast(days=14,region=None):
    d=filtered_frame(region=region)
    if d.empty or 'temperature' not in d:return {'forecast':[],'direction':'unknown','mae':None,'trained':False}
    d['timestamp']=pd.to_datetime(d.timestamp,utc=True); x=d.set_index('timestamp').temperature.resample('D').mean().dropna()
    if len(x)<5:return {'forecast':[],'direction':'insufficient data','mae':None,'trained':False}
    model_doc=db().models.find_one({'model':'linear_regression','region':region or '*'})
    X=np.arange(len(x)).reshape(-1,1); y=x.values; model=LinearRegression().fit(X,y); fitted=model.predict(X)
    # Refresh model with current data whenever new data has advanced beyond the stored training time.
    if not model_doc or model_doc.get('observations',0)!=len(x): train_model(region); model_doc=db().models.find_one({'model':'linear_regression','region':region or '*'})
    pred=model.predict(np.arange(len(x),len(x)+days).reshape(-1,1)); last=x.index[-1]
    return {'trained':True,'direction':'increasing' if model.coef_[0]>.02 else 'decreasing' if model.coef_[0]<-.02 else 'stable','daily_change':round(float(model.coef_[0]),4),'mae':round(float(mean_absolute_error(y,fitted)),3),'r2':round(float(r2_score(y,fitted)),3),'forecast':[{'date':(last+pd.Timedelta(days=i)).strftime('%Y-%m-%d'),'temperature':round(float(v),2)} for i,v in enumerate(pred,1)]}

def ingest_live(r):
    r=dict(r);r['timestamp']=datetime.now(timezone.utc);r['source_type']=r.get('source_type','realtime');dbi=db();dbi.climate_records.insert_one(r)
    fired=[]
    for rule in dbi.alert_rules.find({'enabled':True}):
        field=rule.get('field'); value=r.get(field)
        if isinstance(value,(int,float)):
            op=rule.get('operator'); threshold=rule.get('threshold'); hit=(op=='>' and value>threshold) or (op=='>=' and value>=threshold) or (op=='<' and value<threshold) or (op=='<=' and value<=threshold)
            if hit:
                alert={'type':rule['name'],'severity':rule.get('severity','medium'),'message':f"{field} {value} triggered {rule['name']} ({op} {threshold})",'region':r.get('region','Unknown'),'status':'active','created_at':r['timestamp'],'rule':rule['name']}
                dbi.alerts.insert_one(alert);fired.append(alert)
    return fired
