# Test Plan

| Area | Test | Expected result |
|---|---|---|
| Authentication | Wrong password | Login rejected |
| Authorization | Analyst opens `/admin` | Redirected/denied |
| Ingestion | Valid CSV | Records imported |
| Ingestion | Missing numeric values | Validation reports them and importer repairs where possible |
| Formats | XLSX/JSON/GeoJSON | Parsed/validated |
| Satellite | PNG/JPG/TIFF with satellite source | Imagery asset registered |
| Analytics | Trend | Daily temperature series returned |
| Analytics | Correlation | Variable-pair coefficients returned |
| Anomaly | Outlier temperature | Anomaly stored and displayed |
| ML | Train model | Metrics and model record created |
| ML | Forecast | Future daily temperatures returned |
| Real-time | POST observation | Record stored + rules evaluated |
| Alerts | Temperature above rule | Alert created |
| Support | Ticket submission | Ticket stored |
| Monitoring | Any request | Duration metric recorded |
| Backup | Manual/automatic backup | Timestamped snapshot + manifest |
| Security | HTTPS configuration | Flask can serve TLS when certificates are configured |
| Scaling | Two Flask instances behind reverse proxy | Requests can be distributed |
| Health | `/health` | Database health reported |
