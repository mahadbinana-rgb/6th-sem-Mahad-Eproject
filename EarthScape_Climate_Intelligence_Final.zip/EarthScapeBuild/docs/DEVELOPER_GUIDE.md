# Developer Guide

## Architecture

Browser → Flask routes/templates/API → Python services → MongoDB.

Key modules:

- `routes/`: authentication, UI pages, APIs, administration.
- `services/core.py`: ingestion, normalization, analytics, anomalies, forecasting and model lifecycle.
- `services/backup_service.py`: manual/automatic backups.
- `services/realtime.py`: demonstration live stream simulator.
- `services/audit.py`: security/administration audit trail.
- `middleware.py`: request timing metrics.

## Data collections

`users`, `datasets`, `climate_records`, `satellite_assets`, `anomalies`, `alerts`, `alert_rules`, `models`, `tickets`, `metrics`, `audit_logs`, `backups`, `settings`.

## Extending machine learning

Add a new model in `services/core.py` or a separate service, save its metrics and training timestamp in `models`, and have the analytics API expose the result. Models are refreshed when the current daily observation count changes.
