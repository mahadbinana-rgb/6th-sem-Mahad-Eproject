# EarthScape Requirements Matrix

This matrix maps the supplied Aptech specification to the implemented version.

| Specification requirement | Implementation | Status |
|---|---|---|
| Secure authentication | Password hashing, session login/logout | Implemented |
| Roles such as administrators/analysts | Role field + admin decorator | Implemented |
| Access controls | Admin routes restricted; analyst routes require login | Implemented |
| Diverse climate ingestion | Weather, sensor, historical, satellite dataset source types | Implemented |
| Satellite imagery ingestion | PNG/JPG/JPEG/TIF/TIFF asset registration + metadata | Implemented |
| Weather station records | Structured dataset ingestion | Implemented |
| Environmental sensor data | Structured dataset ingestion | Implemented |
| Historical + real-time data | `climate_records` supports source types; live endpoint | Implemented |
| Common climate data formats | CSV, XLSX, JSON, GeoJSON + imagery assets | Implemented |
| Scalable organized storage | MongoDB collections + timestamp/region/source indexes | Implemented |
| Data partitioning/organization | Compound indexes and filtered queries | Implemented |
| Parallel big-data processing | Replaced by Python processing service by design | Functional equivalent; Hadoop requirement intentionally waived |
| Patterns | Time-series trend analytics | Implemented |
| Anomalies | Statistical z-score detector | Implemented |
| Correlations | Correlation matrix/pairs | Implemented |
| Missing/incomplete data | Validation + numeric median repair | Implemented |
| Real-time streaming | Live ingestion + simulator | Implemented |
| Batch + real-time integration | Same climate-record and alert pipeline | Implemented |
| Predictive ML | Linear-regression trend model | Implemented |
| ML anomaly/trend/correlation areas | Anomaly, forecast and correlation services | Implemented |
| Update/refine models | Training endpoint + refresh when observation count changes | Implemented |
| Interactive dashboards | Dashboard + Analytics pages | Implemented |
| Climate patterns/anomalies/predictions visuals | Charts/tables | Implemented |
| Customizable exploration | Region/date filters | Implemented |
| Automated alerts | Configurable rules | Implemented |
| Real-time notifications | Live API response + alert recording | Implemented |
| Configurable alerting | Admin rule management | Implemented |
| Feedback/support | Ticket system + FAQ | Implemented |
| Performance/resource/processing monitoring | Request metrics + CPU/RAM/disk API | Implemented |
| Optimization strategies | Indexing, bounded queries, normalized ingestion | Implemented |
| Encryption at rest | Hashed credentials; optional encrypted backup contents via ENCRYPTION_KEY | Implemented |
| Encryption in transit | Optional Flask TLS; reverse-proxy TLS deployment guidance | Implemented/configurable |
| Data protection practices | Audit trail, role separation, secret configuration guidance | Implemented |
| 99% uptime target | Health endpoint + multi-instance/load-balancer deployment guidance | Supported by architecture; deployment-dependent |
| Automated backups | Background backup scheduler | Implemented |
| Horizontal scaling | Stateless Flask design + shared MongoDB | Implemented at architecture level |
| Load balancing | Example reverse-proxy configuration | Implemented at deployment level |
| Environmental standards/protocols | UTC timestamps, decimal coordinates/WGS84 convention, documented units | Implemented/documented |
| Big-data industry practices | Indexing, bounded queries, processing separation, audit/monitoring | Implemented |
| User documentation | USER_GUIDE + FAQ | Implemented |
| Developer documentation | DEVELOPER_GUIDE + architecture notes | Implemented |
| Video demonstration | Demo script/checklist provided | User must record final video |

## Intentional technology deviation

The original specification explicitly names HDFS and Hadoop MapReduce as required technologies and lists Impala Server in its software section. This build intentionally excludes Hadoop, HDFS, MapReduce, and Impala to follow the requested architecture. The application behavior remains implemented using Flask, Python services and MongoDB, but an evaluator who requires those named products can still mark that technology requirement as unmet.
