from flask import Blueprint,render_template,redirect,flash,request,current_app,session
from routes.auth import role_required
from services.db import db
from services.core import train_model, regions
from services.backup_service import run_backup
from services.audit import log
bp=Blueprint('admin',__name__,url_prefix='/admin')

@bp.get('/')
@role_required('admin')
def index():
 d=db();stats={'users':d.users.count_documents({}),'records':d.climate_records.count_documents({}),'datasets':d.datasets.count_documents({}),'satellite_assets':d.satellite_assets.count_documents({}),'alerts':d.alerts.count_documents({'status':'active'}),'tickets':d.tickets.count_documents({'status':'open'}),'metrics':d.metrics.count_documents({})}
 return render_template('admin.html',stats=stats,regions=regions(),rules=list(d.alert_rules.find({}, {'_id':0}).sort('name',1)),users=list(d.users.find({}, {'_id':0,'password':0}).sort('username',1)),models=list(d.models.find({}, {'_id':0}).sort('trained_at',-1)),metrics=list(d.metrics.find({}, {'_id':0}).sort('timestamp',-1).limit(12)),backups=list(d.backups.find({}, {'_id':0}).sort('created_at',-1).limit(10)))

@bp.post('/users/<username>/role')
@role_required('admin')
def set_role(username):
 role=request.form.get('role','analyst') if request.form.get('role') in {'admin','analyst'} else 'analyst';db().users.update_one({'username':username},{'$set':{'role':role}});log('role_changed',session.get('username'),{'target':username,'role':role});flash('Role updated.','success');return redirect('/admin')

@bp.post('/rules')
@role_required('admin')
def add_rule():
 name=request.form.get('name','').strip();field=request.form.get('field','').strip();op=request.form.get('operator','>=');severity=request.form.get('severity','medium')
 try:threshold=float(request.form.get('threshold'))
 except:threshold=0
 if name and field in {'temperature','humidity','rainfall','wind_speed','pressure'}:
  db().alert_rules.update_one({'name':name},{'$set':{'name':name,'field':field,'operator':op,'threshold':threshold,'severity':severity,'enabled':True}},upsert=True);log('alert_rule_saved',session.get('username'),{'name':name});flash('Alert rule saved.','success')
 return redirect('/admin')

@bp.post('/rules/<name>/toggle')
@role_required('admin')
def toggle_rule(name):
 r=db().alert_rules.find_one({'name':name})
 if r:db().alert_rules.update_one({'_id':r['_id']},{'$set':{'enabled':not r.get('enabled',True)}})
 return redirect('/admin')

@bp.post('/train')
@role_required('admin')
def train():
 res=train_model(request.form.get('region') or None);flash('Model trained/refreshed successfully.' if res.get('trained') else res.get('message','Training failed.'),'success' if res.get('trained') else 'danger');return redirect('/admin')

@bp.post('/backup')
@role_required('admin')
def backup():
 try:run_backup(current_app.config['BACKUP_FOLDER']);flash('Backup completed.','success')
 except Exception as e:flash(f'Backup failed: {e}','danger')
 return redirect('/admin')
