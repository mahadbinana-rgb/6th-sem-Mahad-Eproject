from flask import Blueprint,jsonify,request,session
from routes.auth import required,role_required
from services.core import summary,trend,rainfall,regions,correlations,anomalies,forecast,ingest_live,train_model
from services.db import db
from services.audit import log
from services.realtime import start,stop

bp=Blueprint('api',__name__,url_prefix='/api')
SIM={'running':False}

@bp.get('/analytics')
@required
def analytics():
    region=request.args.get('region') or None;days=int(request.args.get('days',60));fd=int(request.args.get('forecast_days',14))
    return jsonify({'summary':summary(),'trend':trend(days,region),'rainfall':rainfall(days,region),'regions':regions(),'correlations':correlations(),'anomalies':anomalies(),'forecast':forecast(fd,region)})

@bp.post('/realtime')
@required
def realtime_api():
    fired=ingest_live(request.get_json() or {});log('realtime_ingestion',session.get('username'),{'alerts':len(fired)});return jsonify({'alerts':fired,'ok':True})

@bp.post('/realtime/start')
@role_required('admin')
def realtime_start():start(SIM);return jsonify({'running':True})

@bp.post('/realtime/stop')
@role_required('admin')
def realtime_stop():stop(SIM);return jsonify({'running':False})

@bp.get('/realtime/status')
@required
def realtime_status():return jsonify({'running':SIM['running']})

@bp.post('/models/train')
@role_required('admin')
def train():
    region=request.json.get('region') if request.is_json else None;return jsonify(train_model(region))

@bp.get('/models')
@required
def models():return jsonify(list(db().models.find({}, {'_id':0}).sort('trained_at',-1)))

@bp.get('/system')
@role_required('admin')
def system():
    import os,platform
    try:
        import psutil; cpu=psutil.cpu_percent(interval=.05);ram=psutil.virtual_memory().percent;disk=psutil.disk_usage('/').percent
    except Exception:cpu=ram=disk=None
    latest=list(db().metrics.find({}, {'_id':0}).sort('timestamp',-1).limit(100));avg=round(sum(x.get('duration_ms',0) for x in latest)/len(latest),2) if latest else 0
    return jsonify({'platform':platform.platform(),'python':platform.python_version(),'cpu_percent':cpu,'memory_percent':ram,'disk_percent':disk,'recent_request_count':len(latest),'avg_response_ms':avg})
