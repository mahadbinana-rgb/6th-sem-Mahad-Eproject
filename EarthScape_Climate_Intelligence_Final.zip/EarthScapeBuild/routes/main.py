import os
from datetime import datetime,timezone
from flask import Blueprint,render_template,request,redirect,flash,current_app,session,jsonify
from services.db import db
from services.core import *
from routes.auth import required
from werkzeug.utils import secure_filename
bp=Blueprint('main',__name__)

@bp.get('/')
@required
def home():
 anomalies();return render_template('dashboard.html',s=summary(),trend=trend(),regions=regions(),corr=correlations()[:8],forecast=forecast())

@bp.route('/datasets',methods=['GET','POST'])
@required
def datasets():
 if request.method=='POST':
  f=request.files.get('file');source=request.form.get('source_type','weather_station');desc=request.form.get('description','')
  if not f or not f.filename:flash('Select a file.','warning');return redirect('/datasets')
  name=secure_filename(f.filename);ext=os.path.splitext(name)[1].lower();path=os.path.join(current_app.config['UPLOAD_FOLDER'],name);os.makedirs(current_app.config['UPLOAD_FOLDER'],exist_ok=True);f.save(path)
  try:
   if ext in IMAGE_EXT and source=='satellite_imagery': import_satellite_metadata(path,name,desc);flash('Satellite imagery asset registered successfully.','success')
   elif ext in DATA_EXT:flash(f'Imported {import_file(path,name,source,desc):,} records.','success')
   else:flash('Unsupported file/source combination. Choose an allowed dataset or satellite image.','danger')
  except Exception as e:flash(str(e),'danger')
  return redirect('/datasets')
 return render_template('datasets.html',datasets=list(db().datasets.find({}, {'_id':0}).sort('created_at',-1)),satellites=list(db().satellite_assets.find({}, {'_id':0}).sort('created_at',-1)))

@bp.post('/datasets/validate')
@required
def validate_dataset():
 f=request.files.get('file');
 if not f:return jsonify({'valid':False,'errors':['No file selected']}),400
 ext=os.path.splitext(f.filename)[1].lower()
 if ext not in DATA_EXT:return jsonify({'valid':False,'errors':['Validation supports CSV, XLSX, JSON and GeoJSON datasets.']}),400
 temp=os.path.join(current_app.config['UPLOAD_FOLDER'],'__validate__'+secure_filename(f.filename));os.makedirs(current_app.config['UPLOAD_FOLDER'],exist_ok=True);f.save(temp)
 try:return jsonify(validate_df(load_dataframe(temp)))
 finally:
  try:os.remove(temp)
  except OSError:pass

@bp.get('/analytics')
@required
def analytics_page():return render_template('analytics.html',regions=regions())
@bp.get('/realtime')
@required
def realtime():return render_template('realtime.html')
@bp.get('/alerts')
@required
def alerts_page():return render_template('alerts.html',alerts=list(db().alerts.find({}, {'_id':1,'type':1,'message':1,'severity':1,'region':1,'status':1,'created_at':1}).sort('created_at',-1).limit(100)),anoms=list(db().anomalies.find({}, {'_id':1,'region':1,'temperature':1,'score':1,'status':1,'timestamp':1}).sort('created_at',-1).limit(100)),rules=list(db().alert_rules.find({}, {'_id':0}).sort('name',1)))
@bp.post('/alerts/resolve/<collection>/<key>')
@required
def resolve_alert(collection,key):
 from bson.objectid import ObjectId
 c='alerts' if collection=='alert' else 'anomalies'
 try:db()[c].update_one({'_id':ObjectId(key)},{'$set':{'status':'resolved','resolved_at':datetime.now(timezone.utc)}})
 except Exception:pass
 return redirect('/alerts')
@bp.route('/support',methods=['GET','POST'])
@required
def support():
 if request.method=='POST':db().tickets.insert_one({'username':session['username'],'subject':request.form['subject'],'message':request.form['message'],'status':'open','created_at':datetime.now(timezone.utc)});flash('Ticket submitted.','success');return redirect('/support')
 return render_template('support.html',tickets=list(db().tickets.find({'username':session['username']},{'_id':0}).sort('created_at',-1)))
@bp.get('/health')
def health():
 try:db().command('ping');return {'status':'ok','database':'connected'}
 except Exception:return {'status':'degraded','database':'unavailable'},503
