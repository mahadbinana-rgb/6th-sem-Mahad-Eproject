# EarthScape Climate Intelligence

Flask + MongoDB + HTML/CSS/vanilla JavaScript implementation of the supplied EarthScape Climate Agency specification, without React, Node.js, Hadoop, HDFS, MapReduce or Impala.

## Features
Authentication/roles, dataset ingestion (CSV/XLSX/JSON), data cleaning and missing-value handling, climate analytics, correlations, statistical anomaly detection, linear-regression forecasting, real-time observation ingestion, threshold alerts, dashboards, support tickets, MongoDB storage, and demo data seeding.

## Start
1. Create a Python virtual environment.
2. `pip install -r requirements.txt`
3. Ensure MongoDB is running.
4. `python seed.py`
5. `python app.py`
6. Open `http://127.0.0.1:5000`

Demo admin: `admin` / `admin123`.
