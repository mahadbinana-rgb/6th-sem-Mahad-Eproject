from app import app
from services.db import db
from services.core import import_df
from werkzeug.security import generate_password_hash
import pandas as pd,numpy as np
from datetime import datetime,timedelta,timezone
with app.app_context():
 if not db().users.find_one({'username':'admin'}):db().users.insert_one({'username':'admin','password':generate_password_hash('admin123'),'role':'admin'})
 if db().climate_records.count_documents({})==0:
  rows=[]; start=datetime.now(timezone.utc)-timedelta(days=180)
  for i in range(180):
   for region,base in [('Rahim Yar Khan',30),('Lahore',27),('Karachi',29),('Islamabad',23),('Peshawar',25),('Quetta',20)]:
    rows.append({'timestamp':start+timedelta(days=i),'region':region,'temperature':base+5*np.sin(i/30)+np.random.uniform(-4,4),'humidity':np.random.uniform(25,80),'rainfall':max(0,np.random.normal(5,12)),'wind_speed':np.random.uniform(3,35),'pressure':np.random.uniform(995,1025)})
  import_df(pd.DataFrame(rows),'EarthScape Demo Dataset','demo');print('Seeded 1,080 records. Admin: admin / admin123')
