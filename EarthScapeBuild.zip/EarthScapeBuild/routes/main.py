from flask import Blueprint,render_template,request,redirect,flash
from services.db import db
from services.core import *
from routes.auth import required
import os,pandas as pd
bp=Blueprint('main',__name__)
@bp.get('/')
@required
def home():
 anomalies(); return render_template('dashboard.html',s=summary(),trend=trend(),regions=regions(),corr=correlations()[:8],forecast=forecast())
@bp.route('/datasets',methods=['GET','POST'])
@required
def datasets():
 if request.method=='POST':
  f=request.files.get('file')
  try:
   path=os.path.join('uploads',f.filename);f.save(path); ext=os.path.splitext(path)[1].lower(); df=pd.read_csv(path) if ext=='.csv' else pd.read_excel(path) if ext=='.xlsx' else pd.read_json(path); flash(f'Imported {import_df(df,f.filename):,} records.','success')
  except Exception as e: flash(str(e),'danger')
  return redirect('/datasets')
 return render_template('datasets.html',datasets=list(db().datasets.find({}, {'_id':0}).sort('created_at',-1)))
@bp.get('/realtime')
@required
def realtime():return render_template('realtime.html')
@bp.get('/alerts')
@required
def alerts_page():return render_template('alerts.html',alerts=list(db().alerts.find({}, {'_id':0}).sort('created_at',-1).limit(100)),anoms=list(db().anomalies.find({}, {'_id':0}).sort('timestamp',-1).limit(100)))
@bp.route('/support',methods=['GET','POST'])
@required
def support():
 if request.method=='POST':db().tickets.insert_one({'username':request.form['username'] if 'username' in request.form else 'user','subject':request.form['subject'],'message':request.form['message'],'status':'open'});flash('Ticket submitted.','success');return redirect('/support')
 return render_template('support.html')
