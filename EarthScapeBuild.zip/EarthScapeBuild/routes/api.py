from flask import Blueprint,jsonify,request
from routes.auth import required
from services.core import *
bp=Blueprint('api',__name__,url_prefix='/api')
@bp.get('/analytics')
@required
def analytics():return jsonify({'trend':trend(),'regions':regions(),'correlations':correlations(),'anomalies':anomalies(),'forecast':forecast()})
@bp.post('/realtime')
@required
def realtime_api():return jsonify({'alerts':ingest_live(request.get_json() or {})})
