from flask import Blueprint,render_template,request,redirect,url_for,session,flash
from werkzeug.security import generate_password_hash,check_password_hash
from services.db import db
bp=Blueprint('auth',__name__)
@bp.route('/login',methods=['GET','POST'])
def login():
 if request.method=='POST':
  u=db().users.find_one({'username':request.form['username']})
  if u and check_password_hash(u['password'],request.form['password']):session.update(username=u['username'],role=u['role']);return redirect('/')
  flash('Invalid username or password.','danger')
 return render_template('login.html')
@bp.route('/register',methods=['GET','POST'])
def register():
 if request.method=='POST':
  try: db().users.insert_one({'username':request.form['username'],'password':generate_password_hash(request.form['password']),'role':'analyst'});return redirect('/login')
  except: flash('Username already exists.','danger')
 return render_template('register.html')
@bp.get('/logout')
def logout():session.clear();return redirect('/login')
def required(f):
 from functools import wraps
 @wraps(f)
 def w(*a,**k): return f(*a,**k) if session.get('username') else redirect('/login')
 return w
