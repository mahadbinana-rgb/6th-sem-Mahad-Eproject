from pymongo import MongoClient
_db=None
def init_db(uri,name):
 global _db; _db=MongoClient(uri,serverSelectionTimeoutMS=3000)[name]
 _db.users.create_index('username',unique=True); _db.climate_records.create_index([('timestamp',-1)])
def db(): return _db
