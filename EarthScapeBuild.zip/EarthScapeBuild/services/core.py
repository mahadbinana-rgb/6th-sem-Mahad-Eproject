import pandas as pd,numpy as np
from datetime import datetime,timezone
from services.db import db
from sklearn.linear_model import LinearRegression
ALIASES={'date':'timestamp','datetime':'timestamp','time':'timestamp','location':'region','area':'region','temp':'temperature','temperature_c':'temperature','rain':'rainfall','rainfall_mm':'rainfall','windspeed':'wind_speed','humidity_pct':'humidity'}
NUM=['temperature','humidity','rainfall','wind_speed','pressure','latitude','longitude']
def clean(df):
 df=df.copy(); df.columns=[ALIASES.get(str(x).strip().lower().replace(' ','_'),str(x).strip().lower().replace(' ','_')) for x in df.columns]
 if 'timestamp' not in df: df['timestamp']=datetime.now(timezone.utc)
 df['timestamp']=pd.to_datetime(df['timestamp'],errors='coerce',utc=True).fillna(pd.Timestamp.now(tz='UTC'))
 if 'region' not in df: df['region']='Unknown'
 for c in NUM:
  if c in df: df[c]=pd.to_numeric(df[c],errors='coerce'); m=df[c].median(); df[c]=df[c].fillna(m) if pd.notna(m) else df[c]
 return df.replace({np.nan:None})
def import_df(df,name,source='upload'):
 df=clean(df); rec=[]
 for r in df.to_dict('records'):
  r['timestamp']=r['timestamp'].to_pydatetime() if hasattr(r['timestamp'],'to_pydatetime') else r['timestamp']; r.update(dataset=name,source_type=source); rec.append(r)
 if rec: db().climate_records.insert_many(rec)
 db().datasets.insert_one({'name':name,'source_type':source,'records':len(rec),'columns':list(df.columns),'created_at':datetime.now(timezone.utc)})
 return len(rec)
def frame(): return pd.DataFrame(list(db().climate_records.find({},{'_id':0})))
def summary():
 d=frame(); return {'records':len(d),'regions':int(d.region.nunique()) if not d.empty and 'region' in d else 0,'datasets':db().datasets.count_documents({}),'avg_temp':round(float(d.temperature.mean()),2) if not d.empty and 'temperature' in d else None,'anomalies':db().anomalies.count_documents({'status':'active'})}
def trend():
 d=frame()
 if d.empty or 'temperature' not in d:return []
 d['timestamp']=pd.to_datetime(d.timestamp,utc=True); x=d.groupby(d.timestamp.dt.strftime('%Y-%m-%d')).temperature.mean().tail(30)
 return [{'date':a,'value':round(float(b),2)} for a,b in x.items()]
def regions():
 d=frame()
 if d.empty:return []
 g=d.groupby('region').agg(records=('region','size'),avg_temperature=('temperature','mean'),rainfall=('rainfall','sum')).reset_index()
 return [{'region':r.region,'records':int(r.records),'avg_temperature':round(float(r.avg_temperature),2),'rainfall':round(float(r.rainfall),2)} for _,r in g.iterrows()]
def correlations():
 d=frame(); cols=[c for c in NUM if c in d]
 if len(cols)<2:return []
 c=d[cols].corr(); out=[]
 for i,a in enumerate(cols):
  for b in cols[i+1:]:
   if pd.notna(c.loc[a,b]):out.append({'a':a,'b':b,'value':round(float(c.loc[a,b]),3)})
 return sorted(out,key=lambda x:abs(x['value']),reverse=True)
def anomalies():
 d=frame()
 if d.empty or 'temperature' not in d:return []
 m,s=d.temperature.mean(),d.temperature.std()
 if not s:return []
 d['score']=(d.temperature-m).abs()/s; rows=d[d.score>=2.5].tail(100); out=[]
 for _,r in rows.iterrows():
  doc={'timestamp':r.timestamp,'region':r.region,'temperature':float(r.temperature),'score':round(float(r.score),2),'status':'active','type':'temperature'}
  if not db().anomalies.find_one({'timestamp':doc['timestamp'],'region':doc['region'],'temperature':doc['temperature']}):db().anomalies.insert_one(doc)
  out.append(doc)
 return out
def forecast(days=7):
 d=frame()
 if d.empty or 'temperature' not in d:return []
 d['timestamp']=pd.to_datetime(d.timestamp,utc=True); x=d.set_index('timestamp').temperature.resample('D').mean().dropna()
 if len(x)<3:return []
 model=LinearRegression().fit(np.arange(len(x)).reshape(-1,1),x.values); pred=model.predict(np.arange(len(x),len(x)+days).reshape(-1,1)); last=x.index[-1]
 return [{'date':(last+pd.Timedelta(days=i)).strftime('%Y-%m-%d'),'temperature':round(float(v),2)} for i,v in enumerate(pred,1)]
def ingest_live(r):
 r['timestamp']=datetime.now(timezone.utc); r['source_type']='realtime'; db().climate_records.insert_one(r)
 alerts=[]
 if isinstance(r.get('temperature'),(int,float)) and r['temperature']>=45: alerts.append(('Extreme Temperature','high',f"{r['temperature']}°C in {r.get('region','Unknown')}"))
 if isinstance(r.get('rainfall'),(int,float)) and r['rainfall']>=150: alerts.append(('Extreme Rainfall','high',f"{r['rainfall']} mm in {r.get('region','Unknown')}"))
 for typ,sev,msg in alerts: db().alerts.insert_one({'type':typ,'severity':sev,'message':msg,'region':r.get('region'),'status':'active','created_at':r['timestamp']})
 return alerts
