import os
from flask import Flask
from dotenv import load_dotenv
from services.db import init_db
from routes.auth import bp as auth
from routes.main import bp as main
from routes.api import bp as api

load_dotenv()
app=Flask(__name__)
app.secret_key=os.getenv('SECRET_KEY','change-me')
app.config['UPLOAD_FOLDER']='uploads'
init_db(os.getenv('MONGO_URI','mongodb://localhost:27017/'),os.getenv('MONGO_DB','earthscape'))
app.register_blueprint(auth); app.register_blueprint(main); app.register_blueprint(api)
if __name__=='__main__': app.run(debug=True)