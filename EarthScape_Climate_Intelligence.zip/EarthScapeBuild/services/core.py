"""Climate ingestion, validation and analytics primitives."""

import json
import os
from datetime import datetime, timezone

import numpy as np
import pandas as pd

from services.db import db
from services.settings import get_global_setting

ALIASES = {
    "date": "timestamp", "datetime": "timestamp", "time": "timestamp",
    "location": "region", "area": "region", "city": "region",
    "temp": "temperature", "temperature_c": "temperature",
    "rain": "rainfall", "rainfall_mm": "rainfall",
    "windspeed": "wind_speed", "wind_speed_kmh": "wind_speed",
    "humidity_pct": "humidity", "pressure_hpa": "pressure",
    "clouds": "cloud_cover", "cloudiness": "cloud_cover",
    "cloud_cover_pct": "cloud_cover", "lat": "latitude", "lon": "longitude", "lng": "longitude",
}

TARGETS = ["temperature", "humidity", "pressure", "wind_speed", "rainfall", "cloud_cover"]
DEFAULT_TARGET_VALUES = {"humidity": 55.0, "pressure": 1013.0, "wind_speed": 10.0, "rainfall": 0.0, "cloud_cover": 45.0}
NUMERIC_FIELDS = TARGETS + ["latitude", "longitude"]
DATA_EXTENSIONS = {".csv", ".xlsx", ".json", ".geojson"}
IMAGE_EXTENSIONS = {".png", ".jpg", ".jpeg", ".tif", ".tiff"}


def normalize_columns(dataframe):
    renamed = {}
    for column in dataframe.columns:
        key = str(column).strip().lower().replace(" ", "_").replace("-", "_")
        renamed[column] = ALIASES.get(key, key)
    return dataframe.rename(columns=renamed)


def load_dataframe(path):
    extension = os.path.splitext(path)[1].lower()
    if extension == ".csv":
        return pd.read_csv(path)
    if extension == ".xlsx":
        return pd.read_excel(path)
    if extension == ".json":
        return pd.read_json(path)
    if extension == ".geojson":
        payload = json.loads(open(path, "r", encoding="utf-8").read())
        rows = []
        for feature in payload.get("features", []):
            row = dict(feature.get("properties") or {})
            geometry = feature.get("geometry") or {}
            coords = geometry.get("coordinates") or []
            if geometry.get("type") == "Point" and len(coords) >= 2:
                row["longitude"] = coords[0]
                row["latitude"] = coords[1]
            rows.append(row)
        return pd.DataFrame(rows)
    raise ValueError("Unsupported dataset format")


def validate_df(dataframe):
    data = normalize_columns(dataframe.copy())
    errors = []
    warnings = []

    for column in ["timestamp", "region"]:
        if column not in data.columns:
            errors.append(f"Missing required column: {column}")

    climate_fields = [column for column in TARGETS if column in data.columns]
    if not climate_fields:
        errors.append("At least one climate measurement column is required")

    for column in NUMERIC_FIELDS:
        if column not in data:
            continue
        missing = int(data[column].isna().sum())
        parsed = pd.to_numeric(data[column], errors="coerce")
        invalid = int(parsed.isna().sum() - missing)
        if invalid:
            warnings.append(f"{column}: {invalid} invalid numeric values will be repaired")
        if missing:
            warnings.append(f"{column}: {missing} missing values detected")

    return {
        "valid": not errors,
        "rows": int(len(data)),
        "columns": list(data.columns),
        "errors": errors,
        "warnings": warnings,
    }


def _derive_cloud_cover(data):
    if "cloud_cover" in data:
        return data

    humidity = pd.to_numeric(data.get("humidity"), errors="coerce")
    rainfall = pd.to_numeric(data.get("rainfall"), errors="coerce")
    if humidity is None:
        return data

    humidity = humidity.fillna(humidity.median() if pd.notna(humidity.median()) else 50)
    rain_component = rainfall.fillna(0) * 0.8 if rainfall is not None else 0
    data["cloud_cover"] = np.clip((humidity - 20) * 1.15 + rain_component, 0, 100)
    return data


def clean(dataframe):
    data = normalize_columns(dataframe.copy())

    if "timestamp" not in data:
        data["timestamp"] = datetime.now(timezone.utc)
    data["timestamp"] = pd.to_datetime(data["timestamp"], errors="coerce", utc=True)
    data["timestamp"] = data["timestamp"].fillna(pd.Timestamp.now(tz="UTC"))

    if "region" not in data:
        data["region"] = "Unknown"
    data["region"] = data["region"].fillna("Unknown").astype(str)

    for column in NUMERIC_FIELDS:
        if column not in data:
            continue
        data[column] = pd.to_numeric(data[column], errors="coerce")

        strategy = get_global_setting("missing_strategy", "median")
        if strategy == "forward_fill":
            data[column] = data[column].ffill().bfill()
        elif strategy == "zero":
            data[column] = data[column].fillna(0)
        else:
            median = data[column].median()
            if pd.notna(median):
                data[column] = data[column].fillna(median)

    data = _derive_cloud_cover(data)
    return data.replace({np.nan: None})


def import_df(dataframe, name, source="weather_station", description=""):
    database = db()
    data = clean(dataframe)
    now = datetime.now(timezone.utc)
    records = []

    for row in data.to_dict("records"):
        timestamp = row.get("timestamp")
        if hasattr(timestamp, "to_pydatetime"):
            timestamp = timestamp.to_pydatetime()
        timestamp = timestamp or now
        row["timestamp"] = timestamp
        row.update(
            {
                "dataset": name,
                "source_type": source,
                "partition": timestamp.strftime("%Y-%m"),
                "ingested_at": now,
            }
        )
        records.append(row)

    if records:
        database.climate_records.insert_many(records)

    database.datasets.insert_one(
        {
            "name": name,
            "source_type": source,
            "description": description,
            "records": len(records),
            "columns": list(data.columns),
            "created_at": now,
        }
    )

    return len(records)


def import_file(path, name, source="weather_station", description=""):
    extension = os.path.splitext(path)[1].lower()
    if extension not in DATA_EXTENSIONS:
        raise ValueError("Unsupported climate dataset format")
    return import_df(load_dataframe(path), name, source, description)


def import_satellite_metadata(path, name, description=""):
    metadata = {
        "name": name,
        "source_type": "satellite_imagery",
        "description": description,
        "file_ext": os.path.splitext(path)[1].lower(),
        "size_bytes": os.path.getsize(path),
        "created_at": datetime.now(timezone.utc),
    }

    try:
        from PIL import Image
        image = Image.open(path)
        metadata.update({
            "width": image.width,
            "height": image.height,
            "format": image.format,
            "mode": image.mode,
        })
    except Exception:
        pass

    db().satellite_assets.insert_one(metadata)
    return metadata


def filtered_frame(region=None, start=None, end=None, source_type=None, limit=120000):
    query = {}
    if region:
        query["region"] = region
    if source_type:
        query["source_type"] = source_type
    if start or end:
        bounds = {}
        if start:
            bounds["$gte"] = pd.Timestamp(start, tz="UTC").to_pydatetime()
        if end:
            bounds["$lte"] = pd.Timestamp(end, tz="UTC").to_pydatetime()
        query["timestamp"] = bounds

    records = list(db().climate_records.find(query, {"_id": 0}).sort("timestamp", 1).limit(limit))
    if not records:
        return pd.DataFrame()

    data = pd.DataFrame(records)
    data["timestamp"] = pd.to_datetime(data["timestamp"], utc=True, errors="coerce")
    return data


def frame(limit=120000):
    return filtered_frame(limit=limit)


def summary(region=None):
    data = filtered_frame(region=region)
    database = db()
    if data.empty:
        return {
            "records": 0,
            "regions": 0,
            "datasets": database.datasets.count_documents({}),
            "satellite_assets": database.satellite_assets.count_documents({}),
            "avg_temp": None,
            "min_temp": None,
            "max_temp": None,
            "rainfall": 0,
            "anomalies": database.anomalies.count_documents({"status": "active"}),
            "active_alerts": database.alerts.count_documents({"status": "active"}),
            "tickets": database.tickets.count_documents({"status": "open"}),
        }

    return {
        "records": len(data),
        "regions": int(data["region"].nunique()) if "region" in data else 0,
        "datasets": database.datasets.count_documents({}),
        "satellite_assets": database.satellite_assets.count_documents({}),
        "avg_temp": round(float(data.temperature.mean()), 2) if "temperature" in data else None,
        "min_temp": round(float(data.temperature.min()), 2) if "temperature" in data else None,
        "max_temp": round(float(data.temperature.max()), 2) if "temperature" in data else None,
        "rainfall": round(float(data.rainfall.sum()), 2) if "rainfall" in data else 0,
        "anomalies": database.anomalies.count_documents({"status": "active"}),
        "active_alerts": database.alerts.count_documents({"status": "active"}),
        "tickets": database.tickets.count_documents({"status": "open"}),
    }


def current_conditions(region=None, source_type=None):
    data = filtered_frame(region=region, source_type=source_type, limit=5000)
    if data.empty:
        return {target: None for target in TARGETS} | {"timestamp": None}

    data = data.sort_values("timestamp")
    latest = data.iloc[-1]
    result = {target: (round(float(latest[target]), 2) if target in latest and pd.notna(latest[target]) else None) for target in TARGETS}
    result["timestamp"] = latest.timestamp.strftime("%Y-%m-%d %H:%M UTC")
    return result


def daily_series(region=None, source_type=None, days=90):
    data = filtered_frame(region=region, source_type=source_type)
    if data.empty:
        return pd.DataFrame(columns=TARGETS)

    data = data.set_index("timestamp")
    daily = pd.DataFrame(index=pd.date_range(
        data.index.min().floor("D"), data.index.max().floor("D"), freq="D", tz="UTC"
    ))

    for target in TARGETS:
        if target not in data:
            daily[target] = DEFAULT_TARGET_VALUES.get(target, np.nan)
        elif target == "rainfall":
            daily[target] = data[target].resample("D").sum(min_count=1).reindex(daily.index)
        else:
            daily[target] = data[target].resample("D").mean().reindex(daily.index)
        daily[target] = pd.to_numeric(daily[target], errors="coerce")
        daily[target] = daily[target].interpolate(method="time").ffill().bfill()

    return daily.dropna(how="all").tail(days)


def trend(days=60, region=None, source_type=None):
    data = daily_series(region, source_type, days)
    if data.empty:
        return []
    return [{"date": index.strftime("%Y-%m-%d"), "value": round(float(value), 2)} for index, value in data.temperature.items()]


def rainfall(days=60, region=None, source_type=None):
    data = daily_series(region, source_type, days)
    if data.empty:
        return []
    return [{"date": index.strftime("%Y-%m-%d"), "value": round(float(value), 2)} for index, value in data.rainfall.items()]


def regions():
    data = frame()
    if data.empty:
        return []
    for column in ["temperature", "rainfall"]:
        if column not in data:
            data[column] = 0
    grouped = data.groupby("region").agg(
        records=("region", "size"),
        avg_temperature=("temperature", "mean"),
        rainfall=("rainfall", "sum"),
    ).reset_index()
    return [
        {
            "region": row.region,
            "records": int(row.records),
            "avg_temperature": round(float(row.avg_temperature), 2),
            "rainfall": round(float(row.rainfall), 2),
        }
        for _, row in grouped.iterrows()
    ]


def correlations(region=None):
    data = filtered_frame(region=region)
    columns = [column for column in TARGETS if column in data]
    if len(columns) < 2:
        return []
    matrix = data[columns].corr()
    results = []
    for index, first in enumerate(columns):
        for second in columns[index + 1:]:
            value = matrix.loc[first, second]
            if pd.notna(value):
                results.append({"a": first, "b": second, "value": round(float(value), 3)})
    return sorted(results, key=lambda item: abs(item["value"]), reverse=True)


def anomalies(region=None, threshold=None):
    data = filtered_frame(region=region)
    if data.empty or "temperature" not in data:
        return []
    std = data.temperature.std()
    if not std or pd.isna(std):
        return []
    configured = get_global_setting("anomaly_z", 2.5)
    z_threshold = float(threshold if threshold is not None else configured)
    data["score"] = (data.temperature - data.temperature.mean()).abs() / std
    rows = data[data.score >= z_threshold].tail(200)
    results = []
    for _, row in rows.iterrows():
        document = {
            "timestamp": row.timestamp,
            "region": row.region,
            "temperature": float(row.temperature),
            "score": round(float(row.score), 2),
            "status": "active",
            "type": "temperature",
            "created_at": datetime.now(timezone.utc),
        }
        exists = db().anomalies.find_one({
            "timestamp": document["timestamp"],
            "region": document["region"],
            "temperature": document["temperature"],
        })
        if not exists:
            db().anomalies.insert_one(document)
        results.append(document)
    return results


def ingest_live(payload):
    values = {
        "timestamp": datetime.now(timezone.utc),
        "region": payload.get("region", "Live Station"),
        "temperature": payload.get("temperature"),
        "humidity": payload.get("humidity"),
        "pressure": payload.get("pressure"),
        "wind_speed": payload.get("wind_speed"),
        "rainfall": payload.get("rainfall"),
        "cloud_cover": payload.get("cloud_cover"),
        "latitude": payload.get("latitude"),
        "longitude": payload.get("longitude"),
        "source_type": payload.get("source_type", "realtime"),
        "dataset": payload.get("dataset", "realtime"),
    }
    for key in NUMERIC_FIELDS:
        if values.get(key) is not None:
            try:
                values[key] = float(values[key])
            except (TypeError, ValueError):
                values[key] = None

    if values["cloud_cover"] is None:
        humidity = values.get("humidity") or 50
        rain = values.get("rainfall") or 0
        values["cloud_cover"] = round(float(np.clip((humidity - 20) * 1.15 + rain * 0.8, 0, 100)), 2)

    values["partition"] = values["timestamp"].strftime("%Y-%m")
    db().climate_records.insert_one(values)
    return values
