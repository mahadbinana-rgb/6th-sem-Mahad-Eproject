"""User interface and data settings."""

from datetime import datetime, timezone

from services.db import db

DEFAULT_SETTINGS = {
    "background": "#eef3f5",
    "surface": "#ffffff",
    "text": "#14212a",
    "accent": "#df3734",
    "muted": "#7b8b93",
    "font": "Inter, system-ui, -apple-system, BlinkMacSystemFont, Segoe UI, sans-serif",
    "density": "comfortable",
    "motion": True,
    "intro_animation": True,
    "default_region": "",
    "default_history_days": 90,
    "default_source": "",
    "forecast_days": 10,
    "anomaly_z": 2.5,
    "missing_strategy": "median",
    "auto_train": False,
    "realtime_interval": 5,
}


def load_user_settings(username):
    settings = DEFAULT_SETTINGS.copy()
    if not username:
        return settings

    for item in db().settings.find({"username": username}):
        settings[item["key"]] = item.get("value")
    return settings


def save_user_settings(username, values):
    if not username:
        return

    now = datetime.now(timezone.utc)
    allowed = set(DEFAULT_SETTINGS)
    for key, value in values.items():
        if key not in allowed:
            continue
        db().settings.update_one(
            {"username": username, "key": key},
            {"$set": {"value": value, "updated_at": now}},
            upsert=True,
        )


def get_global_setting(key, fallback=None):
    item = db().settings.find_one({"username": "__global__", "key": key})
    return item.get("value", fallback) if item else fallback


def set_global_setting(key, value):
    db().settings.update_one(
        {"username": "__global__", "key": key},
        {"$set": {
            "username": "__global__",
            "key": key,
            "value": value,
            "updated_at": datetime.now(timezone.utc),
        }},
        upsert=True,
    )
