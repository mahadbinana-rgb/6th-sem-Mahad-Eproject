"""Small security helpers used by configuration and backups."""

import hashlib
import os

from cryptography.fernet import Fernet


def get_fernet():
    raw = os.getenv("ENCRYPTION_KEY", "").strip()
    if not raw:
        return None
    try:
        key = raw.encode()
        return Fernet(key)
    except Exception:
        return None


def encrypt_text(value):
    fernet = get_fernet()
    if not fernet:
        return value
    return fernet.encrypt(value.encode()).decode()


def make_csrf_token(secret):
    return hashlib.sha256(secret.encode()).hexdigest()
