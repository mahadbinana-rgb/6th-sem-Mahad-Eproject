"""Human-readable AI-style analysis generated from model output and data patterns."""

from services.core import correlations, daily_series
from services.forecasting import TARGETS, DISPLAY_NAMES, weather_description


def build_insights(region=None, forecast=None):
    data = daily_series(region=region, days=120)
    statements = []

    if data.empty:
        return ["No climate history is available yet. Import a dataset and train a model first."]

    for target in TARGETS:
        if target not in data or data[target].dropna().empty:
            continue
        values = data[target].dropna()
        recent = float(values.tail(14).mean())
        older = float(values.head(max(14, len(values) // 3)).mean())
        direction = "rising" if recent > older * 1.02 else "falling" if recent < older * 0.98 else "stable"
        statements.append(f"{DISPLAY_NAMES[target]} is {direction} across the recent observation window.")

    corr = correlations(region=region)
    if corr:
        strongest = corr[0]
        statements.append(
            f"The strongest observed relationship is between {DISPLAY_NAMES.get(strongest['a'], strongest['a'])} and "
            f"{DISPLAY_NAMES.get(strongest['b'], strongest['b'])}, with a correlation of {strongest['value']}.")

    if forecast and forecast.get("forecast"):
        first = forecast["forecast"][0]
        statements.append(
            f"The next-day model outlook is {weather_description(first)} with "
            f"{first.get('temperature', 0):.1f}°C and {first.get('rainfall', 0):.1f} mm expected rainfall."
        )

        rainy_days = sum(1 for item in forecast["forecast"] if item.get("rainfall", 0) >= 5)
        if rainy_days:
            statements.append(f"The 10-day forecast contains {rainy_days} days with meaningful rainfall signals.")

    return statements[:8]
