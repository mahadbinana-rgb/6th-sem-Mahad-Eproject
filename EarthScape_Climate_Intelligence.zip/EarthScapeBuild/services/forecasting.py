"""Trainable multi-variable weather forecasting engine."""

import json
import re
from datetime import datetime, timezone
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import ExtraTreesRegressor, GradientBoostingRegressor, RandomForestRegressor
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, r2_score
from sklearn.multioutput import MultiOutputRegressor

from config import MODEL_FOLDER
from services.core import TARGETS, daily_series, filtered_frame
from services.db import db
from services.settings import get_global_setting

LAGS = (1, 2, 3, 7, 14)
WINDOWS = (3, 7, 14)
MODEL_VERSION = "earthscape-weather-v4"
MODEL_DIR = Path(MODEL_FOLDER)
MODEL_DIR.mkdir(parents=True, exist_ok=True)

DISPLAY_NAMES = {
    "temperature": "Temperature", "humidity": "Humidity", "pressure": "Pressure",
    "wind_speed": "Wind speed", "rainfall": "Rainfall", "cloud_cover": "Cloud cover",
}
UNITS = {
    "temperature": "°C", "humidity": "%", "pressure": "hPa",
    "wind_speed": "km/h", "rainfall": "mm", "cloud_cover": "%",
}
CLIP_LIMITS = {"humidity": (0, 100), "rainfall": (0, None), "wind_speed": (0, None), "cloud_cover": (0, 100)}

ALGORITHMS = {
    "random_forest": RandomForestRegressor,
    "extra_trees": ExtraTreesRegressor,
    "linear_regression": LinearRegression,
    "gradient_boosting": GradientBoostingRegressor,
}

DEFAULT_HYPERPARAMETERS = {
    "random_forest": {"n_estimators": 300, "max_depth": 16, "min_samples_leaf": 2, "max_features": 0.75, "random_state": 42, "n_jobs": -1},
    "extra_trees": {"n_estimators": 300, "max_depth": 18, "min_samples_leaf": 2, "max_features": 1.0, "random_state": 42, "n_jobs": -1},
    "linear_regression": {"fit_intercept": True, "n_jobs": None},
    "gradient_boosting": {"n_estimators": 200, "learning_rate": 0.05, "max_depth": 3, "min_samples_leaf": 2, "subsample": 0.9, "random_state": 42},
}


def safe_slug(value):
    return re.sub(r"[^a-z0-9]+", "_", value.lower()).strip("_") or "model"


def build_model(algorithm, hyperparameters):
    if algorithm not in ALGORITHMS:
        raise ValueError(f"Unsupported algorithm: {algorithm}")

    params = DEFAULT_HYPERPARAMETERS[algorithm].copy()
    params.update(hyperparameters or {})

    estimator_class = ALGORITHMS[algorithm]
    if algorithm == "gradient_boosting":
        estimator = estimator_class(**params)
        return MultiOutputRegressor(estimator)
    return estimator_class(**params)


def feature_row(history, timestamp):
    features = {}
    for target in TARGETS:
        for lag in LAGS:
            features[f"{target}_lag_{lag}"] = float(history[target].iloc[-lag])
        for window in WINDOWS:
            values = history[target].tail(window)
            features[f"{target}_mean_{window}"] = float(values.mean())
            features[f"{target}_std_{window}"] = float(values.std(ddof=0))

    day_of_year = timestamp.timetuple().tm_yday
    day_of_week = timestamp.dayofweek
    features["day_of_year_sin"] = np.sin(2 * np.pi * day_of_year / 365.25)
    features["day_of_year_cos"] = np.cos(2 * np.pi * day_of_year / 365.25)
    features["day_of_week_sin"] = np.sin(2 * np.pi * day_of_week / 7)
    features["day_of_week_cos"] = np.cos(2 * np.pi * day_of_week / 7)
    return features


def training_frame(region):
    daily = daily_series(region=region, days=5000)
    if daily.empty:
        return daily, pd.DataFrame(), pd.DataFrame()

    history_required = max(max(LAGS), max(WINDOWS))
    rows = []
    targets = []
    for index in range(history_required, len(daily)):
        history = daily.iloc[:index]
        rows.append(feature_row(history, daily.index[index]))
        targets.append(daily.iloc[index][TARGETS].to_dict())

    return daily, pd.DataFrame(rows), pd.DataFrame(targets)[TARGETS]


def evaluate(actual, predicted):
    results = {}
    for index, target in enumerate(TARGETS):
        results[target] = {
            "mae": round(float(mean_absolute_error(actual[:, index], predicted[:, index])), 3),
            "r2": round(float(r2_score(actual[:, index], predicted[:, index])), 3),
        }
    return results


def _model_path(file_name, region, group_id):
    return MODEL_DIR / f"{safe_slug(file_name)}__{safe_slug(group_id)}__{safe_slug(region)}.joblib"


def _feature_importance(model, feature_names):
    if hasattr(model, "feature_importances_"):
        values = model.feature_importances_
    elif hasattr(model, "estimators_") and model.estimators_ and hasattr(model.estimators_[0], "feature_importances_"):
        values = np.mean([item.feature_importances_ for item in model.estimators_], axis=0)
    else:
        return []
    return sorted(
        [{"feature": name, "importance": round(float(score), 5)} for name, score in zip(feature_names, values)],
        key=lambda item: item["importance"], reverse=True,
    )[:20]


def parse_hyperparameters(raw_json):
    if not raw_json:
        return {}
    try:
        value = json.loads(raw_json)
    except json.JSONDecodeError as exc:
        raise ValueError(f"Invalid hyperparameter JSON: {exc}") from exc
    if not isinstance(value, dict):
        raise ValueError("Hyperparameters must be a JSON object")
    return value


def train_model_group(model_name, file_name, algorithm, hyperparameters, region=None, test_ratio=0.2):
    database = db()
    if region:
        regions = [region]
    else:
        regions = sorted(database.climate_records.distinct("region"))

    file_name = Path(file_name).stem or "earthscape_weather_model"
    group_id = safe_slug(f"{model_name}_{datetime.now(timezone.utc).strftime('%Y%m%d%H%M%S%f')}")
    trained = []
    failures = []

    for region_name in regions:
        daily, features, targets = training_frame(region_name)
        if len(features) < 30:
            failures.append({"region": region_name, "message": "At least 30 training windows are required."})
            continue

        split = max(5, int(len(features) * (1 - test_ratio)))
        split = min(split, len(features) - 1)

        validation_model = build_model(algorithm, hyperparameters)
        validation_model.fit(features.iloc[:split], targets.iloc[:split])
        validation_prediction = validation_model.predict(features.iloc[split:])
        metrics = evaluate(targets.iloc[split:].to_numpy(), validation_prediction)

        final_model = build_model(algorithm, hyperparameters)
        final_model.fit(features, targets)
        path = _model_path(file_name, region_name, group_id)
        joblib.dump(final_model, path)

        metadata = {
            "group_id": group_id,
            "model_name": model_name,
            "file_name": file_name,
            "region": region_name,
            "algorithm": algorithm,
            "model_version": MODEL_VERSION,
            "trained_at": datetime.now(timezone.utc),
            "observations": int(len(daily)),
            "training_rows": int(len(features)),
            "holdout_rows": int(len(features) - split),
            "metrics": metrics,
            "targets": TARGETS,
            "units": UNITS,
            "hyperparameters": hyperparameters,
            "model_path": str(path),
            "top_features": _feature_importance(final_model, list(features.columns)),
        }
        database.forecast_models.update_one(
            {"group_id": group_id, "region": region_name},
            {"$set": metadata},
            upsert=True,
        )
        trained.append(metadata)

    if trained:
        database.model_registry.insert_one({
            "group_id": group_id,
            "model_name": model_name,
            "file_name": file_name,
            "algorithm": algorithm,
            "hyperparameters": hyperparameters,
            "regions": [item["region"] for item in trained],
            "created_at": datetime.now(timezone.utc),
            "active": False,
            "status": "trained",
        })
        if not active_model_group():
            activate_model(group_id)

    return {"group_id": group_id, "trained": trained, "failures": failures}


def list_models():
    return list(db().model_registry.find({}, {"_id": 0}).sort("created_at", -1))


def activate_model(group_id):
    model = db().model_registry.find_one({"group_id": group_id})
    if not model:
        raise ValueError("Model group not found")
    db().model_registry.update_many({}, {"$set": {"active": False}})
    db().model_registry.update_one({"group_id": group_id}, {"$set": {"active": True}})
    db().settings.update_one(
        {"username": "__global__", "key": "active_model_group"},
        {"$set": {"value": group_id, "updated_at": datetime.now(timezone.utc)}},
        upsert=True,
    )
    return model


def active_model_group():
    group_id = get_global_setting("active_model_group")
    if group_id:
        return group_id
    item = db().model_registry.find_one({"active": True})
    return item["group_id"] if item else None


def model_metadata(region, group_id=None):
    group_id = group_id or active_model_group()
    query = {"region": region}
    if group_id:
        query["group_id"] = group_id
    return db().forecast_models.find_one(query, {"_id": 0})


def _clip(target, value):
    lower, upper = CLIP_LIMITS.get(target, (None, None))
    if lower is not None:
        value = max(lower, value)
    if upper is not None:
        value = min(upper, value)
    return float(value)


def weather_description(values, previous=None):
    rain = float(values.get("rainfall") or 0)
    clouds = float(values.get("cloud_cover") or 0)
    wind = float(values.get("wind_speed") or 0)
    humidity = float(values.get("humidity") or 0)
    pressure = float(values.get("pressure") or 1013)

    if rain >= 20 and wind >= 45:
        phrase = "stormy and very wet"
    elif rain >= 10 and wind >= 30:
        phrase = "rainy and windy"
    elif rain >= 10:
        phrase = "rainy"
    elif clouds >= 80:
        phrase = "heavily cloudy"
    elif clouds >= 55:
        phrase = "partly cloudy"
    elif clouds <= 20:
        phrase = "very sunny"
    else:
        phrase = "mostly clear"

    if wind >= 45:
        wind_text = "with strong winds"
    elif wind >= 30:
        wind_text = "with breezy winds"
    else:
        wind_text = "with light winds"

    pressure_text = "stable pressure"
    if previous and previous.get("pressure") is not None:
        delta = pressure - float(previous["pressure"])
        if delta <= -4:
            pressure_text = "falling pressure"
        elif delta >= 4:
            pressure_text = "rising pressure"

    if humidity >= 80 and clouds >= 60:
        humidity_text = "high humidity"
    elif humidity <= 30:
        humidity_text = "dry air"
    else:
        humidity_text = "moderate humidity"

    return f"{phrase}, {wind_text}, {humidity_text}, {pressure_text}"


def forecast_region(region, days=10, group_id=None):
    metadata = model_metadata(region, group_id)
    if not metadata:
        return {"trained": False, "region": region, "forecast": [], "history": [], "message": "No trained model is available for this region."}

    model_path = Path(metadata["model_path"])
    if not model_path.exists():
        return {"trained": False, "region": region, "forecast": [], "history": [], "message": "The saved model file is missing. Retrain the model."}

    model = joblib.load(model_path)
    history = daily_series(region=region, days=3650)
    if len(history) < max(LAGS):
        return {"trained": False, "region": region, "forecast": [], "history": [], "message": "Not enough weather history for forecasting."}

    working = history.copy()
    predictions = []
    previous = working.iloc[-1].to_dict()

    for step in range(1, days + 1):
        next_day = working.index[-1] + pd.Timedelta(days=1)
        row = pd.DataFrame([feature_row(working, next_day)])
        predicted = model.predict(row)[0]
        values = {target: _clip(target, predicted[index]) for index, target in enumerate(TARGETS)}
        values["date"] = next_day.strftime("%Y-%m-%d")
        values["weather"] = weather_description(values, previous)
        predictions.append(values)
        working.loc[next_day, TARGETS] = [values[target] for target in TARGETS]
        previous = values

    current = {target: round(float(history.iloc[-1][target]), 2) for target in TARGETS}
    current["date"] = history.index[-1].strftime("%Y-%m-%d")
    current["weather"] = weather_description(current)

    return {
        "trained": True,
        "region": region,
        "model": metadata,
        "current": current,
        "history": serialize_history(history.tail(365)),
        "forecast": predictions,
    }


def forecast_bundle(region=None, history_days=90, forecast_days=10, source_type=None, group_id=None):
    if region:
        result = forecast_region(region, forecast_days, group_id)
        display_history = daily_series(region=region, source_type=source_type, days=history_days) if source_type else daily_series(region=region, days=history_days)
        result["history"] = serialize_history(display_history)
        if display_history is not None and not display_history.empty:
            current = serialize_history(display_history.tail(1))[0]
            result["current"] = current
        result["history_days"] = history_days
        result["forecast_days"] = forecast_days
        result["selected_model_group"] = group_id or active_model_group()
        return result

    regions = sorted(db().climate_records.distinct("region"))
    region_results = [forecast_region(item, forecast_days, group_id) for item in regions]
    trained = [item for item in region_results if item.get("trained")]
    history = daily_series(source_type=source_type, days=history_days) if source_type else daily_series(days=history_days)
    forecast = aggregate_forecast([item for item in trained])
    current = serialize_history(history.tail(1))[0] if not history.empty else None
    if current:
        current["weather"] = weather_description(current)

    return {
        "trained": bool(trained),
        "region": None,
        "current": current,
        "history": serialize_history(history),
        "forecast": forecast,
        "regions": [item["region"] for item in trained],
        "models": [item.get("model") for item in trained],
        "history_days": history_days,
        "forecast_days": forecast_days,
        "selected_model_group": group_id or active_model_group(),
    }


def aggregate_forecast(results):
    if not results:
        return []
    count = len(results[0]["forecast"])
    output = []
    for index in range(count):
        row = {"date": results[0]["forecast"][index]["date"]}
        for target in TARGETS:
            values = [item["forecast"][index][target] for item in results]
            row[target] = round(float(np.mean(values)), 2)
        row["weather"] = weather_description(row)
        output.append(row)
    return output


def serialize_history(data):
    if data.empty:
        return []
    output = []
    for timestamp, row in data.iterrows():
        item = {"date": timestamp.strftime("%Y-%m-%d")}
        for target in TARGETS:
            item[target] = round(float(row[target]), 2) if target in row and pd.notna(row[target]) else None
        item["weather"] = weather_description(item)
        output.append(item)
    return output
