"""Audit trail helpers."""

from datetime import datetime, timezone

from services.db import db


def log(action, username=None, details=None, status="success"):
    db().audit_logs.insert_one(
        {
            "action": action,
            "username": username,
            "details": details or {},
            "status": status,
            "created_at": datetime.now(timezone.utc),
        }
    )
