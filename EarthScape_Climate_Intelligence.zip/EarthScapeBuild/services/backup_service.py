"""Automated MongoDB backups."""

import json
import os
import threading
import time
from datetime import datetime, timezone

from services.audit import log
from services.db import db
from services.security import encrypt_text

COLLECTIONS = [
    "users", "datasets", "climate_records", "satellite_assets", "anomalies",
    "alerts", "alert_rules", "forecast_models", "model_registry", "tickets",
    "settings", "audit_logs", "metrics", "backups",
]


def run_backup(base_folder):
    os.makedirs(base_folder, exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    destination = os.path.join(base_folder, stamp)
    os.makedirs(destination, exist_ok=True)
    encrypted = bool(os.getenv("ENCRYPTION_KEY"))
    manifest = {"created_at": datetime.now(timezone.utc).isoformat(), "encrypted": encrypted, "collections": []}

    for collection in COLLECTIONS:
        data = list(db()[collection].find({}, {"_id": 0}))
        payload = json.dumps(data, default=str, indent=2)
        suffix = ".json.enc" if encrypted else ".json"
        with open(os.path.join(destination, collection + suffix), "w", encoding="utf-8") as file:
            file.write(encrypt_text(payload) if encrypted else payload)
        manifest["collections"].append({"name": collection, "records": len(data)})

    with open(os.path.join(destination, "manifest.json"), "w", encoding="utf-8") as file:
        json.dump(manifest, file, indent=2)

    db().backups.insert_one({
        "name": stamp,
        "created_at": datetime.now(timezone.utc),
        "path": destination,
        "status": "completed",
        "encrypted": encrypted,
        "records": manifest["collections"],
    })
    log("backup_completed", details={"name": stamp, "encrypted": encrypted})
    return destination


def start_scheduler(folder, hours):
    def loop():
        while True:
            try:
                run_backup(folder)
            except Exception as exc:
                log("backup_failed", details={"error": str(exc)}, status="failed")
            time.sleep(max(60, hours * 3600))

    thread = threading.Thread(target=loop, daemon=True, name="earthscape-backup-scheduler")
    thread.start()
    return thread
