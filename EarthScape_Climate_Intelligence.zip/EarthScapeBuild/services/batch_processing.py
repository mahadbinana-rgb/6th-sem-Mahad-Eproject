"""Map/reduce-style batch analytics without Hadoop.

Large record sets are partitioned by month/region, processed concurrently,
and reduced into one analytical result. This is the application's local
parallel-processing equivalent for the requested climate batch workflow.
"""

from concurrent.futures import ThreadPoolExecutor

import pandas as pd


def _map_partition(records):
    frame = pd.DataFrame(records)
    if frame.empty:
        return {"records": 0, "temperature_sum": 0.0, "rainfall_sum": 0.0}
    return {
        "records": len(frame),
        "temperature_sum": float(frame["temperature"].sum()) if "temperature" in frame else 0.0,
        "rainfall_sum": float(frame["rainfall"].sum()) if "rainfall" in frame else 0.0,
    }


def run_batch_summary(records, workers=4, partition_size=5000):
    partitions = [records[i:i + partition_size] for i in range(0, len(records), partition_size)]
    if not partitions:
        return {"records": 0, "average_temperature": None, "total_rainfall": 0.0, "partitions": 0}
    with ThreadPoolExecutor(max_workers=max(1, workers)) as executor:
        mapped = list(executor.map(_map_partition, partitions))
    total_records = sum(item["records"] for item in mapped)
    temperature_sum = sum(item["temperature_sum"] for item in mapped)
    rainfall_sum = sum(item["rainfall_sum"] for item in mapped)
    return {
        "records": total_records,
        "average_temperature": round(temperature_sum / total_records, 2) if total_records else None,
        "total_rainfall": round(rainfall_sum, 2),
        "partitions": len(mapped),
    }
