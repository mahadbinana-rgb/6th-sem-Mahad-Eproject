"""MongoDB connection and indexes."""

from datetime import datetime, timezone

from pymongo import ASCENDING, DESCENDING, MongoClient

from config import MONGO_DB, MONGO_URI

_database = None
_client = None


def init_db(uri=MONGO_URI, database_name=MONGO_DB):
    global _client, _database

    _client = MongoClient(uri, serverSelectionTimeoutMS=5000)
    _database = _client[database_name]

    indexed = {
        "users": [("username", ASCENDING)],
        "climate_records": [
            [("timestamp", DESCENDING)],
            [("region", ASCENDING), ("timestamp", DESCENDING)],
            [("source_type", ASCENDING), ("timestamp", DESCENDING)],
            [("partition", ASCENDING), ("region", ASCENDING)],
        ],
        "datasets": [[("created_at", DESCENDING)]],
        "satellite_assets": [[("created_at", DESCENDING)]],
        "anomalies": [[("created_at", DESCENDING)], [("region", ASCENDING)]],
        "alerts": [[("created_at", DESCENDING)], [("status", ASCENDING)]],
        "tickets": [[("created_at", DESCENDING)], [("username", ASCENDING)]],
        "alert_rules": [[("name", ASCENDING)]],
        "metrics": [[("timestamp", DESCENDING)]],
        "forecast_models": [[("created_at", DESCENDING)], [("region", ASCENDING)]],
        "model_registry": [[("created_at", DESCENDING)], [("active", ASCENDING)]],
        "settings": [[("username", ASCENDING), ("key", ASCENDING)]],
        "audit_logs": [[("created_at", DESCENDING)]],
        "backups": [[("created_at", DESCENDING)]],
    }

    for collection_name, indexes in indexed.items():
        for index in indexes:
            try:
                _database[collection_name].create_index(index)
            except Exception:
                pass

    try:
        _database.users.create_index("username", unique=True)
    except Exception:
        pass

    defaults = {
        "anomaly_z": 2.5,
        "missing_strategy": "median",
        "forecast_days": 10,
        "auto_train": False,
        "realtime_interval": 5,
    }
    for key, value in defaults.items():
        _database.settings.update_one(
            {"username": "__global__", "key": key},
            {"$setOnInsert": {
                "username": "__global__",
                "key": key,
                "value": value,
                "updated_at": datetime.now(timezone.utc),
            }},
            upsert=True,
        )

    if not _database.alert_rules.count_documents({}):
        _database.alert_rules.insert_many(
            [
                {
                    "name": "Extreme Temperature",
                    "field": "temperature",
                    "operator": ">=",
                    "threshold": 45,
                    "severity": "high",
                    "enabled": True,
                },
                {
                    "name": "Extreme Rainfall",
                    "field": "rainfall",
                    "operator": ">=",
                    "threshold": 150,
                    "severity": "high",
                    "enabled": True,
                },
            ]
        )


def db():
    if _database is None:
        raise RuntimeError("Database has not been initialized")
    return _database
