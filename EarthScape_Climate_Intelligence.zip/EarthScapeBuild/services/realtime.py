"""Real-time observation simulator."""

import random
import threading
import time

from services.core import ingest_live
from services.db import db


def _trigger_alerts(values):
    fired = []
    for rule in db().alert_rules.find({"enabled": True}):
        field = rule.get("field")
        value = values.get(field)
        if not isinstance(value, (int, float)):
            continue
        threshold = float(rule.get("threshold", 0))
        operator = rule.get("operator", ">=")
        triggered = {
            ">": value > threshold,
            ">=": value >= threshold,
            "<": value < threshold,
            "<=": value <= threshold,
        }.get(operator, False)
        if not triggered:
            continue
        alert = {
            "type": rule["name"],
            "severity": rule.get("severity", "medium"),
            "message": f"{field} {value} triggered {rule['name']} ({operator} {threshold})",
            "region": values["region"],
            "status": "active",
            "created_at": values["timestamp"],
            "rule": rule["name"],
        }
        db().alerts.insert_one(alert)
        fired.append(alert)
    return fired


def ingest_and_alert(payload):
    values = ingest_live(payload)
    return values, _trigger_alerts(values)


def run_simulator(flag):
    regions = ["Lahore", "Karachi", "Islamabad", "Rahim Yar Khan", "Peshawar", "Quetta"]
    while flag.get("running"):
        _, _ = ingest_and_alert(
            {
                "region": random.choice(regions),
                "temperature": round(random.uniform(18, 48), 2),
                "humidity": round(random.uniform(20, 90), 2),
                "rainfall": round(max(0, random.gauss(8, 18)), 2),
                "wind_speed": round(random.uniform(2, 55), 2),
                "pressure": round(random.uniform(995, 1025), 2),
                "cloud_cover": round(random.uniform(5, 100), 2),
                "source_type": "realtime_simulation",
            }
        )
        time.sleep(max(2, int(flag.get("interval", 5))))


def start(flag):
    if flag.get("running"):
        return
    flag["running"] = True
    thread = threading.Thread(target=run_simulator, args=(flag,), daemon=True, name="earthscape-live-simulator")
    thread.start()


def stop(flag):
    flag["running"] = False
