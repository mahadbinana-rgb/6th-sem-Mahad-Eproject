"""JSON endpoints used by the interactive pages."""

from flask import Blueprint, jsonify, request, session

from routes.auth import required, role_required
from services.ai_insights import build_insights
from services.audit import log
from services.batch_processing import run_batch_summary
from services.core import anomalies, correlations, current_conditions, daily_series, rainfall, regions, summary, trend
from services.db import db
from services.forecasting import forecast_bundle, list_models, active_model_group, weather_description
from services.realtime import ingest_and_alert, start, stop
from services.settings import get_global_setting

bp = Blueprint("api", __name__, url_prefix="/api")
SIM = {"running": False, "interval": 5}


def safe_int(value, default, minimum, maximum):
    try:
        return max(minimum, min(int(value), maximum))
    except (TypeError, ValueError):
        return default


@bp.get("/analytics")
@required
def analytics():
    region = request.args.get("region") or None
    days = safe_int(request.args.get("days", 90), 90, 7, 365)
    source_type = request.args.get("source") or None
    climate_records = list(db().climate_records.find(
        {"region": region} if region else {},
        {"_id": 0, "temperature": 1, "rainfall": 1},
    ).limit(50000))

    return jsonify({
        "summary": summary(region),
        "batch_processing": run_batch_summary(climate_records),
        "current": current_conditions(region, source_type),
        "trend": trend(days, region, source_type),
        "rainfall": rainfall(days, region, source_type),
        "regions": regions(),
        "correlations": correlations(region),
        "anomalies": anomalies(region),
    })


@bp.get("/forecast/full")
@required
def full_forecast():
    region = request.args.get("region") or None
    history_days = safe_int(request.args.get("history_days", 90), 90, 14, 365)
    forecast_days = safe_int(request.args.get("forecast_days", 10), 10, 1, 10)
    source_type = request.args.get("source") or None
    group_id = request.args.get("model") or None
    bundle = forecast_bundle(region, history_days, forecast_days, source_type, group_id)
    bundle["insights"] = build_insights(region, bundle if bundle.get("forecast") else None)
    return jsonify(bundle)


@bp.get("/current")
@required
def current():
    return jsonify(current_conditions(request.args.get("region") or None, request.args.get("source") or None))


@bp.get("/series")
@required
def series():
    region = request.args.get("region") or None
    source = request.args.get("source") or None
    days = safe_int(request.args.get("days", 90), 90, 7, 365)
    data = daily_series(region=region, source_type=source, days=days)
    rows = []
    for timestamp, row in data.iterrows():
        item = {"date": timestamp.strftime("%Y-%m-%d")}
        for target in ["temperature", "humidity", "pressure", "wind_speed", "rainfall", "cloud_cover"]:
            item[target] = round(float(row[target]), 2) if target in row and row[target] == row[target] else None
        rows.append(item)
    return jsonify(rows)


@bp.get("/alerts/recent")
@required
def recent_alerts():
    items = list(db().alerts.find({"status": "active"}, {"_id": 0}).sort("created_at", -1).limit(10))
    return jsonify(items)


@bp.post("/realtime")
@required
def realtime_api():
    payload = request.get_json(silent=True) or {}
    try:
        values, alerts = ingest_and_alert(payload)
    except Exception as exc:
        return jsonify({"ok": False, "error": str(exc)}), 400

    log("realtime_ingestion", session.get("username"), {"alerts": len(alerts)})
    return jsonify({"ok": True, "values": values, "alerts": alerts})


@bp.post("/realtime/start")
@role_required("admin")
def realtime_start():
    interval = max(2, min(int(request.json.get("interval", 5)), 60) if request.is_json else 5)
    SIM["interval"] = interval
    start(SIM)
    return jsonify({"running": True, "interval": interval})


@bp.post("/realtime/stop")
@role_required("admin")
def realtime_stop():
    stop(SIM)
    return jsonify({"running": False})


@bp.get("/realtime/status")
@required
def realtime_status():
    return jsonify(SIM)


@bp.get("/models")
@required
def models():
    return jsonify({"active": active_model_group(), "models": list_models()})


@bp.get("/models/<group_id>/analysis")
@required
def model_analysis(group_id):
    model = db().model_registry.find_one({"group_id": group_id}, {"_id": 0})
    if not model:
        return jsonify({"error": "Model not found"}), 404
    regional = list(db().forecast_models.find({"group_id": group_id}, {"_id": 0}))
    return jsonify({"registry": model, "regional": regional})


@bp.get("/system")
@role_required("admin")
def system():
    import platform
    try:
        import psutil
        cpu = psutil.cpu_percent(interval=0.05)
        memory = psutil.virtual_memory().percent
        disk = psutil.disk_usage("/").percent
    except Exception:
        cpu = memory = disk = None

    metrics = list(db().metrics.find({}, {"_id": 0}).sort("timestamp", -1).limit(100))
    average = round(sum(item.get("duration_ms", 0) for item in metrics) / len(metrics), 2) if metrics else 0
    return jsonify({
        "platform": platform.platform(),
        "python": platform.python_version(),
        "cpu_percent": cpu,
        "memory_percent": memory,
        "disk_percent": disk,
        "recent_request_count": len(metrics),
        "avg_response_ms": average,
    })


@bp.get("/weather/description")
@required
def weather_words():
    values = {
        key: float(request.args[key])
        for key in ["temperature", "humidity", "pressure", "wind_speed", "rainfall", "cloud_cover"]
        if key in request.args
    }
    return jsonify({"description": weather_description(values)})
