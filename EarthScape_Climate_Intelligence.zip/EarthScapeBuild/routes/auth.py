"""Authentication and authorization routes."""

from datetime import datetime, timezone
from functools import wraps

from flask import Blueprint, flash, redirect, render_template, request, session
from werkzeug.security import check_password_hash, generate_password_hash

from services.audit import log
from services.db import db

bp = Blueprint("auth", __name__)


def required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if not session.get("username"):
            return redirect("/login")
        return view(*args, **kwargs)
    return wrapped


def role_required(*roles):
    def decorator(view):
        @wraps(view)
        def wrapped(*args, **kwargs):
            if not session.get("username"):
                return redirect("/login")
            if session.get("role") not in roles:
                flash("You do not have permission to access that page.", "danger")
                return redirect("/")
            return view(*args, **kwargs)
        return wrapped
    return decorator


@bp.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        user = db().users.find_one({"username": username})
        if user and check_password_hash(user["password"], password):
            session.clear()
            session.update(username=username, role=user.get("role", "analyst"))
            log("login", username)
            return redirect("/")
        log("login_failed", username, status="failed")
        flash("Invalid username or password.", "danger")
    return render_template("login.html")


@bp.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        if len(username) < 3 or len(password) < 6:
            flash("Username must be 3+ characters and password 6+ characters.", "warning")
        elif db().users.find_one({"username": username}):
            flash("Username already exists.", "danger")
        else:
            db().users.insert_one({
                "username": username,
                "password": generate_password_hash(password),
                "role": "analyst",
                "created_at": datetime.now(timezone.utc),
            })
            flash("Account created. You can now sign in.", "success")
            return redirect("/login")
    return render_template("register.html")


@bp.get("/logout")
def logout():
    user = session.get("username")
    if user:
        log("logout", user)
    session.clear()
    return redirect("/login")
