"""User UI and data settings."""

from flask import Blueprint, flash, redirect, render_template, request, session

from routes.auth import required
from services.settings import DEFAULT_SETTINGS, load_user_settings, save_user_settings

bp = Blueprint("settings", __name__, url_prefix="/settings")


@bp.route("/", methods=["GET", "POST"])
@required
def index():
    username = session["username"]
    if request.method == "POST":
        values = {
            "background": request.form.get("background", DEFAULT_SETTINGS["background"]),
            "surface": request.form.get("surface", DEFAULT_SETTINGS["surface"]),
            "text": request.form.get("text", DEFAULT_SETTINGS["text"]),
            "accent": request.form.get("accent", DEFAULT_SETTINGS["accent"]),
            "muted": request.form.get("muted", DEFAULT_SETTINGS["muted"]),
            "font": request.form.get("font", DEFAULT_SETTINGS["font"]),
            "density": request.form.get("density", "comfortable"),
            "motion": request.form.get("motion") == "on",
            "intro_animation": request.form.get("intro_animation") == "on",
            "default_region": request.form.get("default_region", ""),
            "default_history_days": int(request.form.get("default_history_days", 90)),
            "default_source": request.form.get("default_source", ""),
            "forecast_days": 10,
            "anomaly_z": float(request.form.get("anomaly_z", 2.5)),
            "missing_strategy": request.form.get("missing_strategy", "median"),
            "auto_train": request.form.get("auto_train") == "on",
            "realtime_interval": max(2, int(request.form.get("realtime_interval", 5))),
        }
        save_user_settings(username, values)
        flash("Settings saved.", "success")
        return redirect("/settings")
    return render_template("settings.html", settings=load_user_settings(username))
