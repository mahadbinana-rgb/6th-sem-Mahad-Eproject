"""Full AI/ML management hub."""

import json

from flask import Blueprint, flash, redirect, render_template, request, session

from routes.auth import required, role_required
from services.audit import log
from services.forecasting import ALGORITHMS, activate_model, active_model_group, list_models, train_model_group
from services.core import regions
from services.db import db

bp = Blueprint("ml_hub", __name__, url_prefix="/ai-hub")


@bp.get("/")
@required
def index():
    models = list_models()
    active = active_model_group()
    return render_template(
        "ml_hub.html",
        models=models,
        active_model=active,
        algorithms=sorted(ALGORITHMS),
        regions=regions(),
    )


@bp.post("/train")
@role_required("admin")
def train():
    name = request.form.get("model_name", "EarthScape Weather AI").strip()
    file_name = request.form.get("file_name", "earthscape_weather_model").strip()
    algorithm = request.form.get("algorithm", "random_forest")
    region = request.form.get("region") or None
    test_ratio = float(request.form.get("test_ratio", 0.2))
    raw = request.form.get("hyperparameters", "{}").strip()

    try:
        hyperparameters = json.loads(raw) if raw else {}
        if not isinstance(hyperparameters, dict):
            raise ValueError("Hyperparameters must be a JSON object")
        result = train_model_group(name, file_name, algorithm, hyperparameters, region, test_ratio)
        if result["trained"]:
            flash(f"Training complete: {len(result['trained'])} regional model(s) saved.", "success")
            log("ml_model_trained", session.get("username"), {"group_id": result["group_id"], "model_name": name})
        else:
            flash("No region had enough data to train a model.", "warning")
            if result["failures"]:
                flash(result["failures"][0]["message"], "warning")
    except Exception as exc:
        flash(f"Training failed: {exc}", "danger")
    return redirect("/ai-hub")


@bp.post("/activate/<group_id>")
@role_required("admin")
def activate(group_id):
    try:
        activate_model(group_id)
        flash("Selected model is now active for analysis and forecasting.", "success")
        log("ml_model_activated", session.get("username"), {"group_id": group_id})
    except Exception as exc:
        flash(f"Could not activate model: {exc}", "danger")
    return redirect("/ai-hub")
