"""Main web pages and dataset ingestion."""

import os

from flask import Blueprint, current_app, flash, jsonify, redirect, render_template, request, send_from_directory, session
from werkzeug.utils import secure_filename

from routes.auth import required
from services.ai_insights import build_insights
from services.audit import log
from services.core import (
    DATA_EXTENSIONS, IMAGE_EXTENSIONS, anomalies, correlations, import_file,
    import_satellite_metadata, load_dataframe, regions, summary, validate_df,
)
from services.db import db
from services.forecasting import forecast_bundle
from services.settings import load_user_settings

bp = Blueprint("main", __name__)


@bp.get("/")
@required
def home():
    settings = load_user_settings(session["username"])
    region = settings.get("default_region") or None
    forecast = forecast_bundle(region=region, history_days=int(settings.get("default_history_days", 90)), forecast_days=10)
    anomalies(region=region)
    return render_template(
        "dashboard.html",
        s=summary(region),
        regions=regions(),
        forecast=forecast,
        insights=build_insights(region, forecast),
        current=forecast.get("current") or {},
    )


@bp.route("/datasets", methods=["GET", "POST"])
@required
def datasets():
    if request.method == "POST":
        file = request.files.get("file")
        source = request.form.get("source_type", "weather_station")
        description = request.form.get("description", "")
        if not file or not file.filename:
            flash("Select a file.", "warning")
            return redirect("/datasets")

        name = secure_filename(file.filename)
        extension = os.path.splitext(name)[1].lower()
        path = os.path.join(current_app.config["UPLOAD_FOLDER"], name)
        os.makedirs(current_app.config["UPLOAD_FOLDER"], exist_ok=True)
        file.save(path)

        try:
            if extension in IMAGE_EXTENSIONS and source == "satellite_imagery":
                import_satellite_metadata(path, name, description)
                flash("Satellite imagery asset registered successfully.", "success")
            elif extension in DATA_EXTENSIONS:
                imported = import_file(path, name, source, description)
                log("dataset_imported", session.get("username"), {"name": name, "records": imported})
                flash(f"Imported {imported:,} records.", "success")
            else:
                flash("Unsupported file/source combination.", "danger")
        except Exception as exc:
            flash(f"Import failed: {exc}", "danger")
        return redirect("/datasets")

    return render_template(
        "datasets.html",
        datasets=list(db().datasets.find({}, {"_id": 0}).sort("created_at", -1)),
        satellites=list(db().satellite_assets.find({}, {"_id": 0}).sort("created_at", -1)),
    )


@bp.post("/datasets/validate")
@required
def validate_dataset():
    file = request.files.get("file")
    if not file:
        return jsonify({"valid": False, "errors": ["No file selected"]}), 400
    extension = os.path.splitext(file.filename)[1].lower()
    if extension not in DATA_EXTENSIONS:
        return jsonify({"valid": False, "errors": ["Unsupported climate dataset format"]}), 400

    temp = os.path.join(current_app.config["UPLOAD_FOLDER"], "__validate__" + secure_filename(file.filename))
    os.makedirs(current_app.config["UPLOAD_FOLDER"], exist_ok=True)
    file.save(temp)
    try:
        return jsonify(validate_df(load_dataframe(temp)))
    finally:
        try:
            os.remove(temp)
        except OSError:
            pass


@bp.get("/analytics")
@required
def analytics_page():
    return render_template("analytics.html", regions=regions())


@bp.get("/datasets/satellite/<path:filename>")
@required
def satellite_file(filename):
    return send_from_directory(current_app.config["UPLOAD_FOLDER"], filename, as_attachment=False)


@bp.get("/datasets/satellite/<path:filename>/download")
@required
def satellite_download(filename):
    return send_from_directory(current_app.config["UPLOAD_FOLDER"], filename, as_attachment=True)


@bp.get("/realtime")
@required
def realtime():
    return render_template("realtime.html")


@bp.get("/alerts")
@required
def alerts_page():
    database = db()
    return render_template(
        "alerts.html",
        alerts=list(database.alerts.find({}, {"_id": 1, "type": 1, "message": 1, "severity": 1, "region": 1, "status": 1, "created_at": 1}).sort("created_at", -1).limit(100)),
        anoms=list(database.anomalies.find({}, {"_id": 1, "region": 1, "temperature": 1, "score": 1, "status": 1, "timestamp": 1}).sort("created_at", -1).limit(100)),
        rules=list(database.alert_rules.find({}, {"_id": 0}).sort("name", 1)),
    )


@bp.post("/alerts/resolve/<collection>/<key>")
@required
def resolve_alert(collection, key):
    from bson.objectid import ObjectId
    target = "alerts" if collection == "alert" else "anomalies"
    try:
        db()[target].update_one({"_id": ObjectId(key)}, {"$set": {"status": "resolved"}})
    except Exception:
        flash("Could not resolve that item.", "danger")
    return redirect("/alerts")


@bp.route("/support", methods=["GET", "POST"])
@required
def support():
    if request.method == "POST":
        db().tickets.insert_one({
            "username": session["username"],
            "subject": request.form.get("subject", "").strip(),
            "message": request.form.get("message", "").strip(),
            "status": "open",
            "created_at": __import__("datetime").datetime.now(__import__("datetime").timezone.utc),
        })
        flash("Support ticket submitted.", "success")
        return redirect("/support")

    tickets = list(db().tickets.find({"username": session["username"]}, {"_id": 0}).sort("created_at", -1))
    return render_template("support.html", tickets=tickets)


@bp.get("/health")
def health():
    try:
        db().command("ping")
        return {"status": "ok", "database": "connected"}
    except Exception:
        return {"status": "degraded", "database": "unavailable"}, 503
