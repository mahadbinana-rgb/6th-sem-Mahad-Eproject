(() => {
  const body = document.body;
  const intro = document.getElementById('introScreen');
  const loader = document.getElementById('globalLoader');
  const settings = window.EARTHSCAPE_SETTINGS || {};

  if (body.dataset.motion === 'off') body.classList.add('reduced-motion');

  function finishIntro() {
    if (!intro) return;
    intro.classList.add('intro-hidden');
    setTimeout(() => intro.remove(), 700);
  }

  if (intro && !sessionStorage.getItem('earthscape_intro_seen') && !intro.classList.contains('skip-intro')) {
    setTimeout(() => { sessionStorage.setItem('earthscape_intro_seen', '1'); finishIntro(); }, 1500);
  } else {
    finishIntro();
  }

  window.addEventListener('load', () => { if (loader) loader.classList.add('done'); });

  document.querySelectorAll('a[data-nav]').forEach(link => {
    link.addEventListener('click', () => loader && loader.classList.remove('done'));
  });

  const notifyButton = document.getElementById('notifyButton');
  if (notifyButton && 'Notification' in window) {
    notifyButton.addEventListener('click', async () => {
      const permission = await Notification.requestPermission();
      notifyButton.textContent = permission === 'granted' ? '●' : '○';
    });
  }

  let knownAlerts = new Set();
  async function pollAlerts() {
    try {
      const response = await fetch('/api/alerts/recent', { cache: 'no-store' });
      if (!response.ok) return;
      const alerts = await response.json();
      alerts.forEach(alert => {
        const key = `${alert.created_at}|${alert.type}|${alert.message}`;
        if (knownAlerts.has(key)) return;
        knownAlerts.add(key);
        if (knownAlerts.size > 40) knownAlerts = new Set([...knownAlerts].slice(-25));
        if ('Notification' in window && Notification.permission === 'granted') {
          new Notification(`EarthScape alert: ${alert.type}`, { body: alert.message });
        }
      });
    } catch (_) {}
  }
  if (document.body.dataset.motion !== undefined) {
    pollAlerts();
    setInterval(pollAlerts, 8000);
  }
})();
