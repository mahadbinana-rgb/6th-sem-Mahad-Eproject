let metricChart = null;
let featureChart = null;
let forecastChart = null;

const hyperDefaults = {
  random_forest: {
    n_estimators: 300,
    max_depth: 16,
    min_samples_leaf: 2,
    max_features: 0.75,
    random_state: 42,
    n_jobs: -1
  },
  extra_trees: {
    n_estimators: 300,
    max_depth: 18,
    min_samples_leaf: 2,
    max_features: 1.0,
    random_state: 42,
    n_jobs: -1
  },
  gradient_boosting: {
    n_estimators: 200,
    learning_rate: 0.05,
    max_depth: 3,
    min_samples_leaf: 2,
    subsample: 0.9,
    random_state: 42
  },
  linear_regression: {
    fit_intercept: true,
    n_jobs: null
  }
};

function updateHyperparameters() {
  document.getElementById("hyperparameters").value = JSON.stringify(
    hyperDefaults[document.getElementById("algorithm").value],
    null,
    2
  );
}

document.getElementById("algorithm").addEventListener("change", updateHyperparameters);

document.querySelectorAll(".inspect").forEach((button) => {
  button.addEventListener("click", () => {
    document.getElementById("inspectModel").value = button.dataset.group;
    loadModel(button.dataset.group);
  });
});

document.getElementById("inspectModel").addEventListener("change", (event) => {
  if (event.target.value) loadModel(event.target.value);
});

async function loadModel(groupId) {
  const response = await fetch(`/api/models/${groupId}/analysis`);
  const data = await response.json();
  if (!response.ok) return;

  const regions = data.regional || [];
  const first = regions[0];
  const insight = document.getElementById("modelInsight");

  insight.innerHTML = `
    <div class="mini-metrics">
      <div><span>Algorithm</span><b>${data.registry.algorithm}</b></div>
      <div><span>Regions</span><b>${regions.length}</b></div>
      <div><span>Saved file</span><b>${data.registry.file_name}.joblib</b></div>
    </div>
    <p>${data.registry.model_name} is saved as a reusable model group and exposes six forecast targets per region.</p>
  `;

  if (metricChart) metricChart.destroy();
  if (featureChart) featureChart.destroy();
  if (forecastChart) forecastChart.destroy();
  if (!first) return;

  const keys = ["temperature", "humidity", "pressure", "wind_speed", "rainfall", "cloud_cover"];
  const labels = keys.map((key) => key.replace("_", " "));
  const metricCanvas = document.getElementById("modelMetricChart");
  const featureCanvas = document.getElementById("featureChart");

  metricChart = new Chart(metricCanvas, {
    type: "bar",
    data: {
      labels,
      datasets: [
        { label: "R²", data: keys.map((key) => first.metrics?.[key]?.r2 ?? 0) },
        { label: "MAE", data: keys.map((key) => first.metrics?.[key]?.mae ?? 0) }
      ]
    },
    options: { plugins: { legend: { position: "bottom" } } }
  });

  const topFeatures = (first.top_features || []).slice(0, 12);
  featureChart = new Chart(featureCanvas, {
    type: "bar",
    data: {
      labels: topFeatures.map((item) => item.feature),
      datasets: [{
        label: "Feature importance",
        data: topFeatures.map((item) => item.importance)
      }]
    },
    options: {
      indexAxis: "y",
      plugins: { legend: { display: false } }
    }
  });

  loadForecastForModel(groupId);
}

async function loadForecastForModel(groupId) {
  const region = document.getElementById("inspectRegion").value;
  const params = new URLSearchParams({ history_days: 30, forecast_days: 10, model: groupId });
  if (region) params.set("region", region);
  const response = await fetch(`/api/forecast/full?${params}`);
  if (!response.ok) return;
  const bundle = await response.json();
  const rows = bundle.forecast || [];
  if (forecastChart) forecastChart.destroy();
  forecastChart = new Chart(document.getElementById("forecastChart"), {
    type: "line",
    data: {
      labels: rows.map((item) => item.date),
      datasets: [
        { label: "Temperature °C", data: rows.map((item) => item.temperature), tension: .3 },
        { label: "Humidity %", data: rows.map((item) => item.humidity), tension: .3 },
        { label: "Cloud cover %", data: rows.map((item) => item.cloud_cover), tension: .3 }
      ]
    },
    options: { responsive: true, plugins: { legend: { position: "bottom" } } }
  });

  if (rows[0]) {
    document.getElementById("modelInsight").innerHTML += `<p><b>Next-day AI:</b> ${rows[0].weather}. Temperature ${rows[0].temperature}°C, humidity ${rows[0].humidity}%, pressure ${rows[0].pressure} hPa, wind ${rows[0].wind_speed} km/h, rainfall ${rows[0].rainfall} mm and cloud cover ${rows[0].cloud_cover}%.</p>`;
  }
}

document.getElementById("inspectRegion").addEventListener("change", () => {
  const model = document.getElementById("inspectModel").value;
  if (model) loadForecastForModel(model);
});
