"""EarthScape Flask application entry point."""

import os

from flask import Flask, session

from config import (
    AUTO_BACKUP_ENABLED,
    AUTO_BACKUP_HOURS,
    BACKUP_FOLDER,
    MAX_UPLOAD_MB,
    MODEL_FOLDER,
    SECRET_KEY,
    SESSION_COOKIE_SECURE,
    SSL_CERT,
    SSL_ENABLED,
    SSL_KEY,
    UPLOAD_FOLDER,
)
from middleware import install_metrics
from routes.admin import bp as admin_bp
from routes.api import bp as api_bp
from routes.auth import bp as auth_bp
from routes.main import bp as main_bp
from routes.ml_hub import bp as ml_hub_bp
from routes.settings import bp as settings_bp
from services.backup_service import start_scheduler
from services.db import init_db
from services.settings import load_user_settings


def create_app():
    app = Flask(__name__)
    app.secret_key = SECRET_KEY
    app.config.update(
        UPLOAD_FOLDER=UPLOAD_FOLDER,
        BACKUP_FOLDER=BACKUP_FOLDER,
        MODEL_FOLDER=MODEL_FOLDER,
        MAX_CONTENT_LENGTH=MAX_UPLOAD_MB * 1024 * 1024,
        SESSION_COOKIE_HTTPONLY=True,
        SESSION_COOKIE_SAMESITE="Lax",
        SESSION_COOKIE_SECURE=SESSION_COOKIE_SECURE,
    )

    for folder in (UPLOAD_FOLDER, BACKUP_FOLDER, MODEL_FOLDER):
        os.makedirs(folder, exist_ok=True)

    init_db()

    app.register_blueprint(auth_bp)
    app.register_blueprint(main_bp)
    app.register_blueprint(api_bp)
    app.register_blueprint(admin_bp)
    app.register_blueprint(ml_hub_bp)
    app.register_blueprint(settings_bp)
    install_metrics(app)

    @app.context_processor
    def inject_user_settings():
        username = session.get("username")
        return {"ui_settings": load_user_settings(username) if username else {}}

    if AUTO_BACKUP_ENABLED and not os.environ.get("FLASK_RUN_FROM_CLI"):
        start_scheduler(BACKUP_FOLDER, AUTO_BACKUP_HOURS)

    return app


app = create_app()


if __name__ == "__main__":
    kwargs = {
        "host": "0.0.0.0",
        "port": int(os.getenv("PORT", "5000")),
        "debug": False,
    }

    if SSL_ENABLED and SSL_CERT and SSL_KEY:
        kwargs["ssl_context"] = (SSL_CERT, SSL_KEY)

    app.run(**kwargs)
