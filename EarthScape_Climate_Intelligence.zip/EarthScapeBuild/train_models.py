"""Command-line helper for training the default EarthScape weather model."""

from app import app
from services.forecasting import train_model_group


with app.app_context():
    result = train_model_group(
        "EarthScape Weather AI",
        "earthscape_weather_ai",
        "random_forest",
        {
            "n_estimators": 300,
            "max_depth": 16,
            "min_samples_leaf": 2,
            "max_features": 0.75,
            "random_state": 42,
            "n_jobs": -1,
        },
    )

    print(f"Trained {len(result['trained'])} regional models.")
    for failure in result["failures"]:
        print(f"Skipped {failure['region']}: {failure['message']}")
