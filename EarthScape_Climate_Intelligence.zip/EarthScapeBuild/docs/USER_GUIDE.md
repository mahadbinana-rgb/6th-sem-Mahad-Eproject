# User Guide

## First run

Use `admin / admin123` after running `python seed.py`. Change this password before real use.

## Dashboard

The dashboard shows actual current observations, historical charts and a complete 10-day AI forecast. The AI interpretation translates numeric forecast output into phrases such as very sunny, partly cloudy, rainy, rainy and windy, or stormy.

## Climate Analysis

Use region, history-window, source and active-model filters. Toggle climate parameters on/off to control chart density. Historical curves remain separate from the dashed future AI forecast.

## AI / ML Hub

Administrators can train a named model, choose its file name and algorithm, edit hyperparameters in JSON, select a region or all regions, inspect metrics/features and activate the model.

## Data Center

Upload CSV/XLSX/JSON/GeoJSON climate tables or satellite images. The validation step identifies missing/invalid fields before import.

## Live Monitor

Transmit a current sensor observation or, as an administrator, run the simulator. Threshold rules are evaluated immediately.

## Settings

Change background, surface, text, accent and muted colors, font, density, motion and intro animation. Data settings control default region, history, source, anomaly threshold, missing-data strategy and simulator interval.
