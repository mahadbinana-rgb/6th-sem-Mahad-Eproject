# Test Plan

## Automated checks

- Python syntax compilation for every `.py` file.
- Jinja parsing for every `.html` template.
- Pure forecasting tests for feature generation, weather description and output clipping.
- Data cleaning/validation tests.

## Manual acceptance tests

1. Register an analyst and verify analyst access.
2. Log in as admin and verify the Administration and AI/ML Hub controls.
3. Upload the demo CSV and validate before import.
4. Open the Dashboard and verify actual charts and current values.
5. Open Climate Analysis and test region/source/history/parameter filters.
6. Train a custom model with a custom filename and non-default hyperparameters.
7. Activate the new model and verify its name appears in analysis.
8. Open the AI/ML Hub and inspect MAE, R² and feature importance.
9. Open Live Monitor, transmit a value above an alert threshold and confirm an alert is recorded.
10. Enable browser notifications and confirm a new alert generates a browser notification.
11. Open Settings, change UI colors/font and verify the theme persists after refresh.
12. Run a manual backup from Administration and verify a backup manifest is created.
13. Open `/health` and confirm the database health response.
14. Record the working demo using `VIDEO_DEMO_SCRIPT.md`.
