# Video Demonstration Script

1. Login as admin.
2. Show the Dashboard with current actual conditions, historical charts, AI pattern recognition and the 10-day future forecast.
3. Open Data Center and show dataset validation/import plus the satellite imagery library.
4. Open Climate Analysis and demonstrate region/source/history/parameter filters.
5. Open AI/ML Hub. Create a model with a custom name/file name, change hyperparameters, train it and show MAE/R²/feature importance.
6. Activate the model and return to Climate Analysis to show that its output is now used.
7. Open Live Monitor and transmit a live observation that triggers a configurable threshold alert.
8. Open Alerts and resolve the alert/anomaly.
9. Open Settings and demonstrate colors, font, density, motion and data settings.
10. Open Administration and show performance metrics, users, alert rules and backup status.
11. End on the Dashboard and explain the complete flow: ingest → clean → store → analyze → train → forecast → visualize → alert.
