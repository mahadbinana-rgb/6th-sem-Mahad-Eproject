# Developer Guide

## Architecture

Browser → Flask routes/API → services → MongoDB

Important services:

- `services/core.py` — ingestion, validation, cleaning and analytics data access.
- `services/forecasting.py` — feature engineering, model training, persistence, model registry and 10-day forecasting.
- `services/ai_insights.py` — human-readable pattern and forecast explanations.
- `services/batch_processing.py` — partitioned concurrent analytics for larger datasets.
- `services/realtime.py` — live ingestion and alert evaluation.
- `services/settings.py` — per-user UI/data preferences.

## Forecasting model

The model predicts six outputs:

`temperature`, `humidity`, `pressure`, `wind_speed`, `rainfall`, `cloud_cover`

Features include lag 1/2/3/7/14 values, 3/7/14-day means and standard deviations, and seasonal/day-of-week sine/cosine signals. Training uses a chronological holdout rather than random shuffling.

Supported model families:

- Random Forest
- Extra Trees
- Gradient Boosting via `MultiOutputRegressor`
- Linear Regression

Models are saved as Joblib files. The MongoDB model registry stores names, filenames, hyperparameters, metrics and regions. The active model group is stored in global settings and is used by the analysis API.

## Coding style

Python files intentionally use readable functions, descriptive variables and only occasional comments for non-obvious logic.
