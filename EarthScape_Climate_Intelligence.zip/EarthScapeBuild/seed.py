"""Create a useful demo dataset and an initial multi-variable model."""

import random
from datetime import datetime, timedelta, timezone

import numpy as np
import pandas as pd
from werkzeug.security import generate_password_hash

from app import app
from services.core import import_df
from services.db import db
from services.forecasting import train_model_group

random.seed(42)
np.random.seed(42)

REGIONS = {
    "Rahim Yar Khan": {"lat": 28.42, "lon": 70.30, "temp": 30.0},
    "Lahore": {"lat": 31.52, "lon": 74.36, "temp": 27.0},
    "Karachi": {"lat": 24.86, "lon": 67.01, "temp": 29.0},
    "Islamabad": {"lat": 33.69, "lon": 73.04, "temp": 23.0},
    "Peshawar": {"lat": 34.02, "lon": 71.52, "temp": 25.0},
    "Quetta": {"lat": 30.18, "lon": 66.98, "temp": 20.0},
}

with app.app_context():
    database = db()

    if not database.users.find_one({"username": "admin"}):
        database.users.insert_one(
            {
                "username": "admin",
                "password": generate_password_hash("admin123"),
                "role": "admin",
                "created_at": datetime.now(timezone.utc),
            }
        )

    if database.climate_records.count_documents({}) == 0:
        rows = []
        start = datetime.now(timezone.utc) - timedelta(days=365)

        for day in range(365):
            seasonal = 5 * np.sin(day / 30)
            long_term = day * 0.006

            for region, config in REGIONS.items():
                temperature = config["temp"] + seasonal + long_term + np.random.normal(0, 1.7)
                humidity = np.clip(
                    78 - (temperature - config["temp"]) * 1.9 + np.random.normal(0, 6),
                    15,
                    98,
                )
                pressure = 1013 - (temperature - config["temp"]) * 0.7 + np.random.normal(0, 4)
                wind_speed = np.clip(10 + abs(np.random.normal(0, 7)) + 2 * np.sin(day / 12), 1, 55)
                rainfall = max(0, np.random.gamma(1.5, 4) * (humidity / 75))
                cloud_cover = np.clip((humidity - 15) * 1.12 + rainfall * 0.7 + np.random.normal(0, 8), 0, 100)

                rows.append(
                    {
                        "timestamp": start + timedelta(days=day),
                        "region": region,
                        "latitude": config["lat"],
                        "longitude": config["lon"],
                        "temperature": round(float(temperature), 2),
                        "humidity": round(float(humidity), 2),
                        "pressure": round(float(pressure), 2),
                        "wind_speed": round(float(wind_speed), 2),
                        "rainfall": round(float(rainfall), 2),
                        "cloud_cover": round(float(cloud_cover), 2),
                    }
                )

        import_df(pd.DataFrame(rows), "EarthScape Demo Weather History", "demo")
        print(f"Seeded {len(rows):,} multi-variable climate records.")

    if database.model_registry.count_documents({}) == 0:
        result = train_model_group(
            "EarthScape Demo Weather AI",
            "earthscape_demo_weather_ai",
            "random_forest",
            {
                "n_estimators": 250,
                "max_depth": 16,
                "min_samples_leaf": 2,
                "max_features": 0.75,
                "random_state": 42,
                "n_jobs": -1,
            },
        )
        print(f"Trained {len(result['trained'])} regional AI models.")

    print("Admin account: admin / admin123")
