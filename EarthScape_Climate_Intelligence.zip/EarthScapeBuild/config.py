"""Application configuration for EarthScape."""

import os
from pathlib import Path

from dotenv import load_dotenv

load_dotenv()

BASE_DIR = Path(__file__).resolve().parent
SECRET_KEY = os.getenv("SECRET_KEY", "change-this-secret-key")
MONGO_URI = os.getenv("MONGO_URI", "mongodb://localhost:27017/")
MONGO_DB = os.getenv("MONGO_DB", "earthscape")
UPLOAD_FOLDER = str(BASE_DIR / "uploads")
BACKUP_FOLDER = str(BASE_DIR / "backups")
MODEL_FOLDER = str(BASE_DIR / "models")
AUTO_BACKUP_ENABLED = os.getenv("AUTO_BACKUP_ENABLED", "true").lower() == "true"
AUTO_BACKUP_HOURS = max(1, int(os.getenv("AUTO_BACKUP_HOURS", "24")))
SSL_ENABLED = os.getenv("SSL_ENABLED", "false").lower() == "true"
SSL_CERT = os.getenv("SSL_CERT", "")
SSL_KEY = os.getenv("SSL_KEY", "")
SESSION_COOKIE_SECURE = os.getenv("SESSION_COOKIE_SECURE", "false").lower() == "true"
MAX_UPLOAD_MB = max(10, int(os.getenv("MAX_UPLOAD_MB", "100")))
